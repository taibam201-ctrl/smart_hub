<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();

// Check if already has profile
$existingProfile = $conn->query("SELECT * FROM community_directory WHERE user_id = {$user['id']}");
if ($existingProfile && $existingProfile->num_rows > 0) {
    header('Location: edit-profile.php');
    exit();
}

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name'] ?? '');
    $phone = $conn->real_escape_string($_POST['phone'] ?? '');
    $block = $conn->real_escape_string($_POST['block'] ?? '');
    $unit = $conn->real_escape_string($_POST['unit'] ?? '');
    $profession = $conn->real_escape_string($_POST['profession'] ?? '');
    $skills = $conn->real_escape_string($_POST['skills'] ?? '');
    $bio = $conn->real_escape_string($_POST['bio'] ?? '');
    $show_phone = isset($_POST['show_phone']) ? 1 : 0;
    $show_email = isset($_POST['show_email']) ? 1 : 0;
    $is_visible = isset($_POST['is_visible']) ? 1 : 0;
    $userId = $user['id'];

    if ($name) {
        $sql = "INSERT INTO community_directory (user_id, name, phone, block, unit, profession, skills, bio, show_phone, show_email, is_visible)
                VALUES ($userId, '$name', '$phone', '$block', '$unit', '$profession', '$skills', '$bio', $show_phone, $show_email, $is_visible)";
        
        if ($conn->query($sql)) {
            $message = "Profile created successfully!";
            $messageType = "success";
        } else {
            $message = "Error: " . $conn->error;
            $messageType = "error";
        }
    } else {
        $message = "Please enter your name!";
        $messageType = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add My Profile - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>👤 Add My Profile</h1>
            <p>Join the community directory and connect with neighbors</p>
        </div>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>">
                <?= $message ?>
                <?php if ($messageType === 'success'): ?>
                    <br><a href="directory.php" style="color: inherit; text-decoration: underline;">View Directory</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST">
                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="name" placeholder="Your full name" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div class="form-group">
                        <label>Block/Building</label>
                        <select name="block">
                            <option value="">Select Block</option>
                            <option value="A">Block A</option>
                            <option value="B">Block B</option>
                            <option value="C">Block C</option>
                            <option value="D">Block D</option>
                            <option value="E">Block E</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Unit/Apartment Number</label>
                        <input type="text" name="unit" placeholder="e.g., 101, A-12">
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" name="phone" placeholder="Your contact number">
                    </div>

                    <div class="form-group">
                        <label>Profession</label>
                        <input type="text" name="profession" placeholder="e.g., Software Engineer, Doctor">
                    </div>
                </div>

                <div class="form-group">
                    <label>Skills/Expertise</label>
                    <input type="text" name="skills" placeholder="e.g., Plumbing, Tutoring, Photography">
                    <small style="color: rgba(226, 232, 240, 0.6); display: block; margin-top: 0.5rem;">Share skills you can offer to help neighbors</small>
                </div>

                <div class="form-group">
                    <label>Bio</label>
                    <textarea name="bio" placeholder="Tell the community a bit about yourself..." style="min-height: 100px;"></textarea>
                </div>

                <div style="background: rgba(124,58,237,0.1); padding: 1.5rem; border-radius: 12px; margin-bottom: 1.5rem;">
                    <h4 style="margin-bottom: 1rem;">Privacy Settings</h4>
                    <div style="display: flex; flex-direction: column; gap: 0.8rem;">
                        <label style="display: flex; align-items: center; gap: 0.8rem; cursor: pointer;">
                            <input type="checkbox" name="show_phone" checked>
                            <span>Show my phone number in directory</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 0.8rem; cursor: pointer;">
                            <input type="checkbox" name="show_email" checked>
                            <span>Show my email in directory</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 0.8rem; cursor: pointer;">
                            <input type="checkbox" name="is_visible" checked>
                            <span>Make my profile visible to community members</span>
                        </label>
                    </div>
                </div>

                <div style="display: flex; gap: 1rem;">
                    <button type="submit" class="btn">Create Profile</button>
                    <a href="directory.php" class="btn" style="background: rgba(255,255,255,0.1);">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
