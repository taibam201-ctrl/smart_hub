<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$itemId = (int)($_GET['id'] ?? 0);

if (!$itemId) {
    header('Location: lost-found.php');
    exit();
}

$sql = "SELECT lf.*, u.username, u.email FROM lost_found lf JOIN users u ON lf.user_id = u.id WHERE lf.id = $itemId";
$result = $conn->query($sql);

if (!$result || $result->num_rows === 0) {
    header('Location: lost-found.php');
    exit();
}

$item = $result->fetch_assoc();

// Handle mark as resolved
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resolve']) && $item['user_id'] == $user['id']) {
    $conn->query("UPDATE lost_found SET status = 'resolved' WHERE id = $itemId");
    header("Location: lost-found-detail.php?id=$itemId&resolved=1");
    exit();
}

// Handle delete
if (isset($_GET['delete']) && ($item['user_id'] == $user['id'] || isAdmin())) {
    $conn->query("DELETE FROM lost_found WHERE id = $itemId");
    header('Location: lost-found.php');
    exit();
}

$isLost = $item['type'] === 'lost';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($item['title']); ?> - Lost & Found</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <?php if (isset($_GET['resolved'])): ?>
            <div class="message success">Item marked as resolved! Thank you for updating.</div>
        <?php endif; ?>

        <div style="max-width: 900px; margin: 0 auto;">
            <div style="background: var(--glass); border: 1px solid <?= $isLost ? 'rgba(239, 68, 68, 0.5)' : 'rgba(16, 185, 129, 0.5)'; ?>; border-radius: 20px; overflow: hidden;">
                
                <div style="height: 350px; overflow: hidden; position: relative;">
                    <img src="<?= htmlspecialchars($item['image_url']); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                    <?php if ($item['status'] === 'resolved'): ?>
                        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(16, 185, 129, 0.9); padding: 1rem 3rem; border-radius: 10px; font-size: 2rem; font-weight: 800;">RESOLVED</div>
                    <?php endif; ?>
                    <span style="position: absolute; top: 1rem; left: 1rem; background: <?= $isLost ? 'linear-gradient(135deg, #ef4444, #dc2626)' : 'linear-gradient(135deg, #10b981, #059669)'; ?>; padding: 0.5rem 1.5rem; border-radius: 20px; font-weight: 700; font-size: 1.1rem;">
                        <?= $isLost ? '🚨 LOST' : '✅ FOUND'; ?>
                    </span>
                    <span style="position: absolute; top: 1rem; right: 1rem; background: linear-gradient(135deg, var(--primary), var(--secondary)); padding: 0.5rem 1rem; border-radius: 20px; font-weight: 700;">
                        <?= htmlspecialchars($item['category']); ?>
                    </span>
                </div>

                <div style="padding: 2rem;">
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
                        <h1 style="font-size: 2rem; margin: 0;"><?= htmlspecialchars($item['title']); ?></h1>
                        
                        <?php if ($item['user_id'] == $user['id']): ?>
                            <div style="display: flex; gap: 0.5rem;">
                                <?php if ($item['status'] !== 'resolved'): ?>
                                    <form method="POST" style="display: inline;">
                                        <button type="submit" name="resolve" class="btn btn-small" style="background: linear-gradient(135deg, #10b981, #059669);" onclick="return confirm('Mark this item as resolved/found?');">
                                            ✅ Mark Resolved
                                        </button>
                                    </form>
                                <?php endif; ?>
                                <a href="lost-found-detail.php?id=<?= $itemId; ?>&delete=1" class="btn btn-small btn-danger" onclick="return confirm('Delete this report?');">Delete</a>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 2rem; padding: 1.5rem; background: rgba(124,58,237,0.1); border-radius: 12px;">
                        <div>
                            <small style="opacity: 0.7;">📍 Location</small>
                            <p style="font-weight: 700; margin: 0;"><?= htmlspecialchars($item['location']); ?></p>
                        </div>
                        <div>
                            <small style="opacity: 0.7;">📅 Date <?= $isLost ? 'Lost' : 'Found'; ?></small>
                            <p style="font-weight: 700; margin: 0;"><?= date('M d, Y', strtotime($item['date_occurred'])); ?></p>
                        </div>
                        <div>
                            <small style="opacity: 0.7;">👤 Reported By</small>
                            <p style="font-weight: 700; margin: 0; color: var(--secondary);"><?= htmlspecialchars($item['username']); ?></p>
                        </div>
                        <div>
                            <small style="opacity: 0.7;">Status</small>
                            <p style="font-weight: 700; margin: 0; color: <?= $item['status'] === 'resolved' ? 'var(--success)' : ($isLost ? 'var(--error)' : 'var(--secondary)'); ?>;">
                                <?= ucfirst($item['status']); ?>
                            </p>
                        </div>
                    </div>

                    <div style="margin-bottom: 2rem;">
                        <h3 style="margin-bottom: 1rem;">Description</h3>
                        <p style="line-height: 1.8; opacity: 0.9;"><?= nl2br(htmlspecialchars($item['description'])); ?></p>
                    </div>

                    <?php if ($item['status'] !== 'resolved' && $item['user_id'] != $user['id']): ?>
                        <div style="background: rgba(6, 182, 212, 0.1); border: 1px solid var(--secondary); border-radius: 12px; padding: 1.5rem;">
                            <h3 style="margin-bottom: 1rem;">📞 Contact Information</h3>
                            <p style="margin-bottom: 0.5rem;"><strong>Phone:</strong> <?= htmlspecialchars($item['contact_phone']); ?></p>
                            <p style="margin-bottom: 0;"><strong>Email:</strong> <?= htmlspecialchars($item['email']); ?></p>
                            <p style="margin-top: 1rem; font-size: 0.9rem; opacity: 0.8;">
                                <?= $isLost ? 'If you found this item, please contact the owner.' : 'If this is your item, please contact to claim it.'; ?>
                            </p>
                        </div>
                    <?php endif; ?>

                    <a href="lost-found.php" class="btn" style="margin-top: 2rem;">← Back to Lost & Found</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
