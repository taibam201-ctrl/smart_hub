<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question = $conn->real_escape_string($_POST['question'] ?? '');
    $category = $conn->real_escape_string($_POST['category'] ?? 'General');
    $details = $conn->real_escape_string($_POST['details'] ?? '');
    $userId = $user['id'];

    if ($question) {
        $sql = "INSERT INTO faq_questions (user_id, question, category, details, status) 
                VALUES ($userId, '$question', '$category', '$details', 'pending')";
        
        if ($conn->query($sql)) {
            $message = "Your question has been submitted! We'll review it and add it to our FAQs or respond directly.";
            $messageType = "success";
        } else {
            $message = "Error: " . $conn->error;
            $messageType = "error";
        }
    } else {
        $message = "Please enter your question!";
        $messageType = "error";
    }
}

// Get user's previous questions
$result = $conn->query("SELECT * FROM faq_questions WHERE user_id = {$user['id']} ORDER BY created_at DESC");
$myQuestions = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

$categories = ['General', 'Events', 'Payments', 'Facilities', 'Rules', 'Maintenance', 'Security', 'Other'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ask a Question - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>💬 Ask a Question</h1>
            <p>Can't find the answer you're looking for? Submit your question here.</p>
        </div>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>">
                <?= $message ?>
                <?php if ($messageType === 'success'): ?>
                    <br><a href="faqs.php" style="color: inherit; text-decoration: underline;">Browse FAQs</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST">
                <div class="form-group">
                    <label>Your Question *</label>
                    <input type="text" name="question" placeholder="e.g., How do I book the community hall?" required>
                </div>

                <div class="form-group">
                    <label>Category</label>
                    <select name="category">
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat; ?>"><?= $cat; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Additional Details (Optional)</label>
                    <textarea name="details" placeholder="Provide any additional context or details about your question..." style="min-height: 100px;"></textarea>
                </div>

                <div style="display: flex; gap: 1rem;">
                    <button type="submit" class="btn">Submit Question</button>
                    <a href="faqs.php" class="btn" style="background: rgba(255,255,255,0.1);">Back to FAQs</a>
                </div>
            </form>
        </div>

        <!-- User's Previous Questions -->
        <?php if (count($myQuestions) > 0): ?>
            <div style="margin-top: 3rem;">
                <h2 style="margin-bottom: 1.5rem;">📝 My Questions</h2>
                
                <?php foreach ($myQuestions as $q): ?>
                    <div style="background: var(--glass); border: 1px solid rgba(124,58,237,0.3); border-radius: 16px; padding: 1.5rem; margin-bottom: 1rem;">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.5rem; flex-wrap: wrap; gap: 0.5rem;">
                            <h4 style="margin: 0;"><?= htmlspecialchars($q['question']); ?></h4>
                            <span style="padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.8rem; font-weight: 600;
                                background: <?php 
                                    if ($q['status'] === 'answered') echo 'rgba(16, 185, 129, 0.2); color: var(--success)';
                                    elseif ($q['status'] === 'rejected') echo 'rgba(239, 68, 68, 0.2); color: var(--error)';
                                    else echo 'rgba(245, 158, 11, 0.2); color: var(--warning)';
                                ?>;">
                                <?= ucfirst($q['status']); ?>
                            </span>
                        </div>
                        
                        <p style="font-size: 0.85rem; opacity: 0.6; margin-bottom: 0.5rem;">
                            📁 <?= htmlspecialchars($q['category']); ?> • 📅 <?= date('M d, Y', strtotime($q['created_at'])); ?>
                        </p>
                        
                        <?php if ($q['details']): ?>
                            <p style="opacity: 0.8; font-size: 0.9rem;"><?= htmlspecialchars($q['details']); ?></p>
                        <?php endif; ?>
                        
                        <?php if ($q['admin_response']): ?>
                            <div style="background: rgba(6, 182, 212, 0.1); border-left: 3px solid var(--secondary); padding: 1rem; margin-top: 1rem; border-radius: 0 10px 10px 0;">
                                <strong style="color: var(--secondary);">Admin Response:</strong>
                                <p style="margin: 0.5rem 0 0;"><?= nl2br(htmlspecialchars($q['admin_response'])); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
