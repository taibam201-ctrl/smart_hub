<?php
require __DIR__ . '/config.php';
requireLogin();

if (!isAdmin()) {
    header('Location: announcements.php');
    exit();
}

$user = getCurrentUser();
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title    = $conn->real_escape_string($_POST['title'] ?? '');
    $category = $conn->real_escape_string($_POST['category'] ?? '');
    $content  = $conn->real_escape_string($_POST['content'] ?? '');
    $isPinned = isset($_POST['is_pinned']) ? 1 : 0;

    $imageUrl = 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=500&h=300&fit=crop';
    $userId   = $user['id'];

    if ($title && $category && $content) {
        $sql = "
            INSERT INTO announcements
            (title, category, content, image_url, created_by, is_pinned, status)
            VALUES
            ('$title', '$category', '$content', '$imageUrl', $userId, $isPinned, 'published')
        ";

        if ($conn->query($sql)) {
            $message = 'Announcement published successfully!';
            $messageType = 'success';
        } else {
            $message = 'Error publishing announcement!';
            $messageType = 'error';
        }
    } else {
        $message = 'Please fill all required fields!';
        $messageType = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Announcement - Smart Community Hub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<!-- ✅ ONE CONSISTENT NAVBAR -->
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container">

    <div class="hero">
        <h1>Create New Announcement</h1>
        <p>Share important updates and news with your community</p>
    </div>

    <?php if ($message): ?>
        <div class="message <?= htmlspecialchars($messageType); ?>">
            <?= htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="form-container">
        <form method="POST">

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:2rem;">
                <div class="form-group">
                    <label>Announcement Title *</label>
                    <input type="text" name="title" required>
                </div>

                <div class="form-group">
                    <label>Category *</label>
                    <select name="category" required>
                        <option value="">Select Category</option>
                        <option value="Announcement">Announcement</option>
                        <option value="Community">Community</option>
                        <option value="Meeting">Meeting</option>
                        <option value="Event">Event</option>
                        <option value="Update">Update</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Content *</label>
                <textarea name="content" required style="min-height:250px;"></textarea>
            </div>

            <div class="form-group" style="display:flex; align-items:center; gap:1rem;">
                <input type="checkbox" name="is_pinned" id="is_pinned">
                <label for="is_pinned">Pin this announcement</label>
            </div>

            <button class="btn">Publish Announcement</button>
        </form>
    </div>

</div>

</body>
</html>
