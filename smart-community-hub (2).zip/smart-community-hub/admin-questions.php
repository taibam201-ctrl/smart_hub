<?php
include 'config.php';
requireLogin();

if (!isAdmin()) {
    header('Location: faqs.php');
    exit();
}

$user = getCurrentUser();
$message = '';
$messageType = '';

// Handle response
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['question_id'])) {
    $questionId = (int)$_POST['question_id'];
    $response = $conn->real_escape_string($_POST['response'] ?? '');
    $status = $conn->real_escape_string($_POST['status'] ?? 'answered');
    $addToFaq = isset($_POST['add_to_faq']) ? 1 : 0;

    $sql = "UPDATE faq_questions SET admin_response = '$response', status = '$status' WHERE id = $questionId";
    
    if ($conn->query($sql)) {
        // If adding to FAQ
        if ($addToFaq && $response) {
            $qResult = $conn->query("SELECT * FROM faq_questions WHERE id = $questionId");
            $q = $qResult->fetch_assoc();
            
            $question = $conn->real_escape_string($q['question']);
            $category = $conn->real_escape_string($q['category']);
            
            $conn->query("INSERT INTO faqs (question, answer, category, is_published, is_pinned, created_by) 
                         VALUES ('$question', '$response', '$category', 1, 0, {$user['id']})");
        }
        
        $message = "Response saved successfully!";
        $messageType = "success";
    } else {
        $message = "Error: " . $conn->error;
        $messageType = "error";
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    $conn->query("DELETE FROM faq_questions WHERE id = $deleteId");
    header("Location: admin-questions.php");
    exit();
}

// Get filter
$statusFilter = isset($_GET['status']) ? $conn->real_escape_string($_GET['status']) : '';

$sql = "SELECT q.*, u.username, u.email FROM faq_questions q JOIN users u ON q.user_id = u.id";
if ($statusFilter) {
    $sql .= " WHERE q.status = '$statusFilter'";
}
$sql .= " ORDER BY FIELD(q.status, 'pending', 'answered', 'rejected'), q.created_at DESC";

$result = $conn->query($sql);
$questions = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Count by status
$pendingCount = $conn->query("SELECT COUNT(*) as c FROM faq_questions WHERE status = 'pending'")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Questions - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>📨 User Questions</h1>
            <p>Review and respond to questions submitted by community members</p>
        </div>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>"><?= $message ?></div>
        <?php endif; ?>

        <!-- Filter Tabs -->
        <div class="tabs" style="margin-bottom: 2rem;">
            <a href="admin-questions.php" class="tab-btn <?= !$statusFilter ? 'active' : ''; ?>">
                All (<?= count($questions); ?>)
            </a>
            <a href="admin-questions.php?status=pending" class="tab-btn <?= $statusFilter === 'pending' ? 'active' : ''; ?>">
                ⏳ Pending (<?= $pendingCount; ?>)
            </a>
            <a href="admin-questions.php?status=answered" class="tab-btn <?= $statusFilter === 'answered' ? 'active' : ''; ?>">
                ✅ Answered
            </a>
            <a href="admin-questions.php?status=rejected" class="tab-btn <?= $statusFilter === 'rejected' ? 'active' : ''; ?>">
                ❌ Rejected
            </a>
            <a href="manage-faqs.php" class="btn btn-small" style="margin-left: auto;">Manage FAQs</a>
        </div>

        <?php if (count($questions) > 0): ?>
            <?php foreach ($questions as $q): ?>
                <div style="background: var(--glass); border: 1px solid <?= $q['status'] === 'pending' ? 'rgba(245, 158, 11, 0.5)' : 'rgba(124,58,237,0.3)'; ?>; border-radius: 16px; padding: 1.5rem; margin-bottom: 1.5rem;">
                    
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem; flex-wrap: wrap; gap: 1rem;">
                        <div>
                            <h3 style="margin: 0 0 0.5rem;"><?= htmlspecialchars($q['question']); ?></h3>
                            <p style="font-size: 0.85rem; opacity: 0.7; margin: 0;">
                                👤 <?= htmlspecialchars($q['username']); ?> (<?= htmlspecialchars($q['email']); ?>) • 
                                📁 <?= htmlspecialchars($q['category']); ?> • 
                                📅 <?= date('M d, Y h:i A', strtotime($q['created_at'])); ?>
                            </p>
                        </div>
                        <span style="padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.8rem; font-weight: 600;
                            background: <?php 
                                if ($q['status'] === 'answered') echo 'rgba(16, 185, 129, 0.2); color: var(--success)';
                                elseif ($q['status'] === 'rejected') echo 'rgba(239, 68, 68, 0.2); color: var(--error)';
                                else echo 'rgba(245, 158, 11, 0.2); color: var(--warning)';
                            ?>;">
                            <?= ucfirst($q['status']); ?>
                        </span>
                    </div>

                    <?php if ($q['details']): ?>
                        <p style="opacity: 0.85; margin-bottom: 1rem; padding: 1rem; background: rgba(0,0,0,0.2); border-radius: 10px;">
                            <?= nl2br(htmlspecialchars($q['details'])); ?>
                        </p>
                    <?php endif; ?>

                    <?php if ($q['admin_response']): ?>
                        <div style="background: rgba(6, 182, 212, 0.1); border-left: 3px solid var(--secondary); padding: 1rem; margin-bottom: 1rem; border-radius: 0 10px 10px 0;">
                            <strong style="color: var(--secondary);">Your Response:</strong>
                            <p style="margin: 0.5rem 0 0;"><?= nl2br(htmlspecialchars($q['admin_response'])); ?></p>
                        </div>
                    <?php endif; ?>

                    <!-- Response Form -->
                    <form method="POST" style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid rgba(124,58,237,0.2);">
                        <input type="hidden" name="question_id" value="<?= $q['id']; ?>">
                        
                        <div class="form-group" style="margin-bottom: 1rem;">
                            <label>Response</label>
                            <textarea name="response" placeholder="Type your response here..." style="min-height: 100px;"><?= htmlspecialchars($q['admin_response'] ?? ''); ?></textarea>
                        </div>

                        <div style="display: flex; gap: 1rem; align-items: center; flex-wrap: wrap;">
                            <select name="status" style="padding: 0.5rem 1rem; background: rgba(255,255,255,0.08); border: 1px solid rgba(124,58,237,0.3); border-radius: 8px; color: var(--text);">
                                <option value="pending" <?= $q['status'] === 'pending' ? 'selected' : ''; ?>>⏳ Pending</option>
                                <option value="answered" <?= $q['status'] === 'answered' ? 'selected' : ''; ?>>✅ Answered</option>
                                <option value="rejected" <?= $q['status'] === 'rejected' ? 'selected' : ''; ?>>❌ Rejected</option>
                            </select>

                            <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                                <input type="checkbox" name="add_to_faq">
                                <span>Also add to public FAQs</span>
                            </label>

                            <button type="submit" class="btn btn-small">Save Response</button>
                            
                            <a href="admin-questions.php?delete=<?= $q['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('Delete this question?');" style="margin-left: auto;">Delete</a>
                        </div>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <h3>No Questions</h3>
                <p>No questions have been submitted<?= $statusFilter ? ' with this status' : ''; ?>.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
