<?php
include 'config.php';
requireLogin();

if (!isAdmin()) {
    header('Location: polls.php');
    exit();
}

$user = getCurrentUser();
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question = $conn->real_escape_string($_POST['question'] ?? '');
    $options = $_POST['options'] ?? [];
    $end_date = $_POST['end_date'] ? $conn->real_escape_string($_POST['end_date']) : null;
    $userId = $user['id'];

    // Filter empty options
    $options = array_filter($options, function($opt) { return trim($opt) !== ''; });

    if ($question && count($options) >= 2) {
        $endDateSql = $end_date ? "'$end_date'" : "NULL";
        $sql = "INSERT INTO polls (question, created_by, end_date, status) VALUES ('$question', $userId, $endDateSql, 'active')";
        
        if ($conn->query($sql)) {
            $pollId = $conn->insert_id;
            
            // Insert options
            foreach ($options as $option) {
                $optionEsc = $conn->real_escape_string($option);
                $conn->query("INSERT INTO poll_options (poll_id, option_text) VALUES ($pollId, '$optionEsc')");
            }
            
            $message = "Poll created successfully!";
            $messageType = "success";
        } else {
            $message = "Error: " . $conn->error;
            $messageType = "error";
        }
    } else {
        $message = "Please enter a question and at least 2 options!";
        $messageType = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Poll - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>📊 Create New Poll</h1>
            <p>Ask the community a question and gather their opinions</p>
        </div>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>">
                <?= $message ?>
                <?php if ($messageType === 'success'): ?>
                    <br><a href="polls.php" style="color: inherit; text-decoration: underline;">View All Polls</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST">
                <div class="form-group">
                    <label>Poll Question *</label>
                    <input type="text" name="question" placeholder="e.g., What should be our next community event?" required>
                </div>

                <div class="form-group">
                    <label>End Date (Optional)</label>
                    <input type="date" name="end_date" min="<?= date('Y-m-d'); ?>">
                    <small style="color: rgba(226, 232, 240, 0.6); display: block; margin-top: 0.5rem;">Leave empty for no end date</small>
                </div>

                <div class="form-group">
                    <label>Options * (minimum 2)</label>
                    <div id="options-container">
                        <input type="text" name="options[]" placeholder="Option 1" required style="margin-bottom: 0.8rem;">
                        <input type="text" name="options[]" placeholder="Option 2" required style="margin-bottom: 0.8rem;">
                        <input type="text" name="options[]" placeholder="Option 3 (optional)" style="margin-bottom: 0.8rem;">
                        <input type="text" name="options[]" placeholder="Option 4 (optional)" style="margin-bottom: 0.8rem;">
                    </div>
                    <button type="button" onclick="addOption()" class="btn btn-small" style="background: rgba(255,255,255,0.1); margin-top: 0.5rem;">
                        + Add Another Option
                    </button>
                </div>

                <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                    <button type="submit" class="btn">Create Poll</button>
                    <a href="polls.php" class="btn" style="background: rgba(255,255,255,0.1);">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        let optionCount = 4;
        function addOption() {
            optionCount++;
            const container = document.getElementById('options-container');
            const input = document.createElement('input');
            input.type = 'text';
            input.name = 'options[]';
            input.placeholder = 'Option ' + optionCount + ' (optional)';
            input.style.marginBottom = '0.8rem';
            container.appendChild(input);
        }
    </script>
</body>
</html>
