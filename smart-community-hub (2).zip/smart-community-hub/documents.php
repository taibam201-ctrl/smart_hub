<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$categoryFilter = isset($_GET['category']) ? $conn->real_escape_string($_GET['category']) : '';
$searchTerm = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$sql = "SELECT d.*, u.username FROM documents d JOIN users u ON d.uploaded_by = u.id WHERE 1=1";

if ($categoryFilter) {
    $sql .= " AND d.category = '$categoryFilter'";
}

if ($searchTerm) {
    $sql .= " AND (d.title LIKE '%$searchTerm%' OR d.description LIKE '%$searchTerm%')";
}

$sql .= " ORDER BY d.created_at DESC";

$result = $conn->query($sql);
$documents = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Group by category for display
$categories = [
    'Rules & Regulations' => '📋',
    'Forms' => '📝',
    'Meeting Minutes' => '📑',
    'Financial Reports' => '💰',
    'Notices' => '📢',
    'Guidelines' => '📖',
    'Other' => '📄'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Center - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>📁 Document Center</h1>
            <p>Access important community documents, forms, and resources</p>
        </div>

        <?php if (isAdmin()): ?>
            <div style="text-align: right; margin-bottom: 1.5rem;">
                <a href="upload-document.php" class="btn">+ Upload Document</a>
            </div>
        <?php endif; ?>

        <div class="search-filter">
            <form method="GET" style="display: contents;">
                <input type="text" name="search" placeholder="Search documents..." value="<?= htmlspecialchars($searchTerm); ?>">
                
                <select name="category">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat => $icon): ?>
                        <option value="<?= $cat; ?>" <?= $categoryFilter === $cat ? 'selected' : ''; ?>>
                            <?= $icon . ' ' . $cat; ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <button type="submit" class="btn btn-small">Search</button>
            </form>
        </div>

        <?php if (count($documents) > 0): ?>
            <div style="display: flex; flex-direction: column; gap: 1rem;">
                <?php foreach ($documents as $doc): 
                    $icon = $categories[$doc['category']] ?? '📄';
                    $fileSize = $doc['file_size'] ? round($doc['file_size'] / 1024, 1) . ' KB' : 'N/A';
                ?>
                    <div style="background: var(--glass); border: 1px solid rgba(124,58,237,0.3); border-radius: 16px; padding: 1.5rem; display: flex; align-items: center; gap: 1.5rem; transition: all 0.3s ease;" onmouseover="this.style.borderColor='var(--secondary)'" onmouseout="this.style.borderColor='rgba(124,58,237,0.3)'">
                        
                        <div style="width: 60px; height: 60px; background: linear-gradient(135deg, var(--primary), var(--secondary)); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; flex-shrink: 0;">
                            <?= $icon; ?>
                        </div>
                        
                        <div style="flex: 1; min-width: 0;">
                            <h3 style="font-size: 1.1rem; margin-bottom: 0.3rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                <?= htmlspecialchars($doc['title']); ?>
                            </h3>
                            <p style="font-size: 0.85rem; opacity: 0.7; margin-bottom: 0.5rem;">
                                <?= substr(htmlspecialchars($doc['description']), 0, 100); ?>
                            </p>
                            <div style="display: flex; gap: 1.5rem; font-size: 0.8rem; opacity: 0.6; flex-wrap: wrap;">
                                <span>📁 <?= htmlspecialchars($doc['category']); ?></span>
                                <span>👤 <?= htmlspecialchars($doc['username']); ?></span>
                                <span>📅 <?= date('M d, Y', strtotime($doc['created_at'])); ?></span>
                                <span>📊 <?= $fileSize; ?></span>
                                <span>👁 <?= $doc['downloads']; ?> downloads</span>
                            </div>
                        </div>
                        
                        <div style="display: flex; gap: 0.5rem; flex-shrink: 0;">
                            <a href="download-document.php?id=<?= $doc['id']; ?>" class="btn btn-small">
                                ⬇️ Download
                            </a>
                            <?php if (isAdmin()): ?>
                                <a href="delete-document.php?id=<?= $doc['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('Delete this document?');">
                                    🗑️
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h3>No Documents Found</h3>
                <p>No documents have been uploaded yet<?= $searchTerm || $categoryFilter ? ' matching your search' : ''; ?>.</p>
                <?php if ($searchTerm || $categoryFilter): ?>
                    <a href="documents.php" class="btn">Clear Filters</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
