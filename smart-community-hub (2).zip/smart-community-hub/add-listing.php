<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $conn->real_escape_string($_POST['title'] ?? '');
    $category = $conn->real_escape_string($_POST['category'] ?? '');
    $description = $conn->real_escape_string($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $condition = $conn->real_escape_string($_POST['condition'] ?? 'good');
    $contact_phone = $conn->real_escape_string($_POST['contact_phone'] ?? '');
    $userId = $user['id'];

    $imageUrl = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&h=300&fit=crop';

    if ($title && $category && $description) {
        $sql = "INSERT INTO marketplace (user_id, title, category, description, price, `condition`, contact_phone, image_url, status)
                VALUES ($userId, '$title', '$category', '$description', $price, '$condition', '$contact_phone', '$imageUrl', 'available')";
        
        if ($conn->query($sql)) {
            $message = "Listing created successfully!";
            $messageType = "success";
        } else {
            $message = "Error creating listing: " . $conn->error;
            $messageType = "error";
        }
    } else {
        $message = "Please fill all required fields!";
        $messageType = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Listing - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>📦 Add New Listing</h1>
            <p>Sell or give away items to your community members</p>
        </div>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>">
                <?= $message ?>
                <?php if ($messageType === 'success'): ?>
                    <br><a href="marketplace.php" style="color: inherit; text-decoration: underline;">View Marketplace</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST">
                <div class="form-group">
                    <label>Item Title *</label>
                    <input type="text" name="title" placeholder="e.g., iPhone 12 Pro Max" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div class="form-group">
                        <label>Category *</label>
                        <select name="category" required>
                            <option value="">Select Category</option>
                            <option value="Electronics">Electronics</option>
                            <option value="Furniture">Furniture</option>
                            <option value="Clothing">Clothing</option>
                            <option value="Books">Books</option>
                            <option value="Sports">Sports & Fitness</option>
                            <option value="Home">Home & Garden</option>
                            <option value="Services">Services</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Condition *</label>
                        <select name="condition" required>
                            <option value="new">New</option>
                            <option value="like_new">Like New</option>
                            <option value="good" selected>Good</option>
                            <option value="fair">Fair</option>
                            <option value="poor">Poor</option>
                        </select>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div class="form-group">
                        <label>Price (Rs.) *</label>
                        <input type="number" name="price" placeholder="Enter 0 for free items" min="0" required>
                    </div>

                    <div class="form-group">
                        <label>Contact Phone *</label>
                        <input type="tel" name="contact_phone" placeholder="Your phone number" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Description *</label>
                    <textarea name="description" placeholder="Describe your item in detail..." required style="min-height: 150px;"></textarea>
                </div>

                <div style="display: flex; gap: 1rem;">
                    <button type="submit" class="btn">Create Listing</button>
                    <a href="marketplace.php" class="btn" style="background: rgba(255,255,255,0.1);">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
