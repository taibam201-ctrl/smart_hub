<?php
include 'config.php';
requireLogin();

$docId = (int)($_GET['id'] ?? 0);

if (!$docId) {
    header('Location: documents.php');
    exit();
}

$result = $conn->query("SELECT * FROM documents WHERE id = $docId");

if (!$result || $result->num_rows === 0) {
    header('Location: documents.php');
    exit();
}

$doc = $result->fetch_assoc();

// Increment download count
$conn->query("UPDATE documents SET downloads = downloads + 1 WHERE id = $docId");

// If file exists, serve it
if ($doc['file_path'] && file_exists($doc['file_path'])) {
    $filename = $doc['file_name'] ?: basename($doc['file_path']);
    
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($doc['file_path']));
    
    readfile($doc['file_path']);
    exit();
} else {
    // If no file, redirect back with error
    header('Location: documents.php?error=file_not_found');
    exit();
}
?>
