<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();

// Fetch announcements
$query = "SELECT a.*, u.username 
          FROM announcements a 
          JOIN users u ON a.created_by = u.id 
          WHERE a.status = 'published'
          ORDER BY a.created_at DESC";

$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements - SmartHub</title>

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">

    <style>
        /* Wrapper */
        .announcement-wrapper {
            max-width: 1000px;
            margin: 2rem auto;
        }

        /* Card */
        .announcement-card {
            display: flex;
            gap: 2rem;
            padding: 1.5rem;
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(124,58,237,0.3);
            border-radius: 20px;
            margin-bottom: 2rem;
            backdrop-filter: blur(12px);
            transition: 0.2s;
        }

        .announcement-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.35);
        }

        .announcement-image {
            width: 260px;
            height: 160px;
            border-radius: 15px;
            overflow: hidden;
            flex-shrink: 0;
        }

        .announcement-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .announcement-content {
            flex: 1;
        }

        .announcement-category {
            display: inline-block;
            padding: 0.3rem 1rem;
            font-size: 0.8rem;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border-radius: 20px;
            margin-bottom: 0.6rem;
            font-weight: 700;
        }

        .announcement-title {
            font-size: 1.6rem;
            font-weight: 900;
            margin-bottom: .5rem;
        }

        .announcement-meta {
            display: flex;
            gap: 2rem;
            opacity: 0.85;
            margin-bottom: 1rem;
            flex-wrap: wrap;
        }

        .read-more-btn {
            padding: 0.7rem 1.4rem;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border-radius: 10px;
            font-weight: 700;
            text-decoration: none;
        }
    </style>
</head>

<body>

<!-- BACKGROUND -->
<div class="background">
    <div class="float-shape shape-1"></div>
    <div class="float-shape shape-2"></div>
    <div class="float-shape shape-3"></div>
</div>

<!-- ✅ SHARED NAVBAR -->
<?php include 'partials/navbar.php'; ?>

<!-- HERO -->
<div class="hero" style="max-width:1000px;">
    <h1>Announcements</h1>
    <p>Stay updated with the latest community news and updates!</p>
</div>

<div class="announcement-wrapper">

    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="announcement-card">

            <div class="announcement-image">
                <img src="<?= htmlspecialchars($row['image_url']); ?>" alt="Announcement Image">
            </div>

            <div class="announcement-content">

                <div class="announcement-category">
                    <?= htmlspecialchars($row['category']); ?>
                </div>

                <div class="announcement-title">
                    <?= htmlspecialchars($row['title']); ?>
                </div>

                <div class="announcement-meta">
                    <span>👤 <?= htmlspecialchars($row['username']); ?></span>
                    <span>📅 <?= date("M d, Y", strtotime($row['created_at'])); ?></span>
                    <span>👁 <?= (int)$row['views']; ?> views</span>
                </div>

                <a href="announcement-detail.php?id=<?= $row['id']; ?>" class="read-more-btn">
                    Read More
                </a>

            </div>
        </div>
    <?php endwhile; ?>

</div>

</body>
</html>
