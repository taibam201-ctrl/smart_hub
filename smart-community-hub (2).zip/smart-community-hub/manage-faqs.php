<?php
include 'config.php';
requireLogin();

if (!isAdmin()) {
    header('Location: faqs.php');
    exit();
}

$user = getCurrentUser();
$message = '';
$messageType = '';

// Handle delete
if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    if ($conn->query("DELETE FROM faqs WHERE id = $deleteId")) {
        $message = "FAQ deleted successfully!";
        $messageType = "success";
    }
}

// Handle toggle publish
if (isset($_GET['toggle'])) {
    $toggleId = (int)$_GET['toggle'];
    $conn->query("UPDATE faqs SET is_published = NOT is_published WHERE id = $toggleId");
    header("Location: manage-faqs.php");
    exit();
}

// Handle toggle pin
if (isset($_GET['pin'])) {
    $pinId = (int)$_GET['pin'];
    $conn->query("UPDATE faqs SET is_pinned = NOT is_pinned WHERE id = $pinId");
    header("Location: manage-faqs.php");
    exit();
}

// Handle add/edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $faqId = (int)($_POST['faq_id'] ?? 0);
    $question = $conn->real_escape_string($_POST['question'] ?? '');
    $answer = $conn->real_escape_string($_POST['answer'] ?? '');
    $category = $conn->real_escape_string($_POST['category'] ?? 'General');
    $sort_order = (int)($_POST['sort_order'] ?? 0);
    $is_pinned = isset($_POST['is_pinned']) ? 1 : 0;
    $is_published = isset($_POST['is_published']) ? 1 : 0;

    if ($question && $answer) {
        if ($faqId > 0) {
            // Update existing
            $sql = "UPDATE faqs SET question = '$question', answer = '$answer', category = '$category', 
                    sort_order = $sort_order, is_pinned = $is_pinned, is_published = $is_published 
                    WHERE id = $faqId";
            $successMsg = "FAQ updated successfully!";
        } else {
            // Add new
            $sql = "INSERT INTO faqs (question, answer, category, sort_order, is_pinned, is_published, created_by) 
                    VALUES ('$question', '$answer', '$category', $sort_order, $is_pinned, $is_published, {$user['id']})";
            $successMsg = "FAQ added successfully!";
        }
        
        if ($conn->query($sql)) {
            $message = $successMsg;
            $messageType = "success";
        } else {
            $message = "Error: " . $conn->error;
            $messageType = "error";
        }
    } else {
        $message = "Please fill question and answer!";
        $messageType = "error";
    }
}

// Get FAQ for editing
$editFaq = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $result = $conn->query("SELECT * FROM faqs WHERE id = $editId");
    if ($result && $result->num_rows > 0) {
        $editFaq = $result->fetch_assoc();
    }
}

// Get all FAQs
$result = $conn->query("SELECT f.*, u.username FROM faqs f JOIN users u ON f.created_by = u.id ORDER BY f.category, f.sort_order, f.created_at DESC");
$faqs = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

$categories = ['General', 'Events', 'Payments', 'Facilities', 'Rules', 'Maintenance', 'Security', 'Other'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage FAQs - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>⚙️ Manage FAQs</h1>
            <p>Add, edit, and organize frequently asked questions</p>
        </div>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>"><?= $message ?></div>
        <?php endif; ?>

        <!-- Add/Edit Form -->
        <div class="form-container" style="margin-bottom: 3rem;">
            <h2 style="margin-bottom: 1.5rem;"><?= $editFaq ? '✏️ Edit FAQ' : '➕ Add New FAQ'; ?></h2>
            <form method="POST">
                <input type="hidden" name="faq_id" value="<?= $editFaq['id'] ?? 0; ?>">
                
                <div class="form-group">
                    <label>Question *</label>
                    <input type="text" name="question" placeholder="e.g., What are the community timings?" value="<?= htmlspecialchars($editFaq['question'] ?? ''); ?>" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div class="form-group">
                        <label>Category *</label>
                        <select name="category" required>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat; ?>" <?= ($editFaq['category'] ?? '') === $cat ? 'selected' : ''; ?>><?= $cat; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Sort Order</label>
                        <input type="number" name="sort_order" value="<?= $editFaq['sort_order'] ?? 0; ?>" min="0">
                        <small style="color: rgba(226, 232, 240, 0.6);">Lower numbers appear first</small>
                    </div>
                </div>

                <div class="form-group">
                    <label>Answer *</label>
                    <textarea name="answer" placeholder="Provide a detailed answer..." required style="min-height: 150px;"><?= htmlspecialchars($editFaq['answer'] ?? ''); ?></textarea>
                </div>

                <div style="display: flex; gap: 2rem; margin-bottom: 1.5rem;">
                    <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                        <input type="checkbox" name="is_published" <?= ($editFaq['is_published'] ?? 1) ? 'checked' : ''; ?>>
                        <span>Published (visible to users)</span>
                    </label>
                    <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                        <input type="checkbox" name="is_pinned" <?= ($editFaq['is_pinned'] ?? 0) ? 'checked' : ''; ?>>
                        <span>📌 Pin to top</span>
                    </label>
                </div>

                <div style="display: flex; gap: 1rem;">
                    <button type="submit" class="btn"><?= $editFaq ? 'Update FAQ' : 'Add FAQ'; ?></button>
                    <?php if ($editFaq): ?>
                        <a href="manage-faqs.php" class="btn" style="background: rgba(255,255,255,0.1);">Cancel</a>
                    <?php endif; ?>
                    <a href="faqs.php" class="btn" style="background: rgba(255,255,255,0.1); margin-left: auto;">View Public FAQs</a>
                </div>
            </form>
        </div>

        <!-- FAQs List -->
        <h2 style="margin-bottom: 1.5rem;">📋 All FAQs (<?= count($faqs); ?>)</h2>
        
        <?php if (count($faqs) > 0): ?>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Order</th>
                            <th>Question</th>
                            <th>Category</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($faqs as $faq): ?>
                            <tr>
                                <td><?= $faq['sort_order']; ?></td>
                                <td>
                                    <?= htmlspecialchars(substr($faq['question'], 0, 50)); ?>...
                                    <?php if ($faq['is_pinned']): ?>
                                        <span style="color: var(--secondary);">📌</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($faq['category']); ?></td>
                                <td>
                                    <?php if ($faq['is_published']): ?>
                                        <span style="color: var(--success);">✅ Published</span>
                                    <?php else: ?>
                                        <span style="color: var(--error);">❌ Draft</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                                        <a href="manage-faqs.php?edit=<?= $faq['id']; ?>" class="btn btn-small">Edit</a>
                                        <a href="manage-faqs.php?toggle=<?= $faq['id']; ?>" class="btn btn-small" style="background: rgba(255,255,255,0.1);">
                                            <?= $faq['is_published'] ? 'Unpublish' : 'Publish'; ?>
                                        </a>
                                        <a href="manage-faqs.php?pin=<?= $faq['id']; ?>" class="btn btn-small" style="background: rgba(255,255,255,0.1);">
                                            <?= $faq['is_pinned'] ? 'Unpin' : 'Pin'; ?>
                                        </a>
                                        <a href="manage-faqs.php?delete=<?= $faq['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('Delete this FAQ?');">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h3>No FAQs Yet</h3>
                <p>Add your first FAQ using the form above.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
