<?php
include 'config.php';
requireLogin();

if (!isAdmin()) {
    header('Location: documents.php');
    exit();
}

$docId = (int)($_GET['id'] ?? 0);

if ($docId) {
    // Get file path first
    $result = $conn->query("SELECT file_path FROM documents WHERE id = $docId");
    if ($result && $result->num_rows > 0) {
        $doc = $result->fetch_assoc();
        
        // Delete physical file if exists
        if ($doc['file_path'] && file_exists($doc['file_path'])) {
            unlink($doc['file_path']);
        }
        
        // Delete database record
        $conn->query("DELETE FROM documents WHERE id = $docId");
    }
}

header('Location: documents.php');
exit();
?>
