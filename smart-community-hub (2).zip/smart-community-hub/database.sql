-- =====================================================
-- SMART COMMUNITY HUB - DATABASE SETUP
-- Run this in phpMyAdmin after creating 'smart_hub' database
-- =====================================================

-- =====================================================
-- EXISTING TABLES (if not already created)
-- =====================================================

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    location VARCHAR(255) NOT NULL,
    description TEXT,
    capacity INT NOT NULL,
    registered INT DEFAULT 0,
    image_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    participants INT DEFAULT 1,
    special_requests TEXT,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    content TEXT NOT NULL,
    image_url VARCHAR(500),
    created_by INT NOT NULL,
    is_pinned BOOLEAN DEFAULT FALSE,
    status ENUM('draft', 'published') DEFAULT 'published',
    views INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS announcement_comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    announcement_id INT NOT NULL,
    user_id INT NOT NULL,
    comment TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (announcement_id) REFERENCES announcements(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    status ENUM('Pending', 'Resolved', 'Rejected') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =====================================================
-- NEW MODULE: MARKETPLACE
-- =====================================================

CREATE TABLE IF NOT EXISTS marketplace (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(10, 2) DEFAULT 0,
    `condition` ENUM('new', 'like_new', 'good', 'fair', 'poor') DEFAULT 'good',
    contact_phone VARCHAR(20),
    image_url VARCHAR(500),
    status ENUM('available', 'sold', 'removed') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =====================================================
-- NEW MODULE: LOST AND FOUND
-- =====================================================

CREATE TABLE IF NOT EXISTS lost_found (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('lost', 'found') NOT NULL,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    location VARCHAR(255) NOT NULL,
    date_occurred DATE NOT NULL,
    contact_phone VARCHAR(20),
    image_url VARCHAR(500),
    status ENUM('open', 'resolved') DEFAULT 'open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =====================================================
-- NEW MODULE: POLLING SYSTEM
-- =====================================================

CREATE TABLE IF NOT EXISTS polls (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question VARCHAR(500) NOT NULL,
    created_by INT NOT NULL,
    end_date DATE NULL,
    status ENUM('active', 'closed') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS poll_options (
    id INT AUTO_INCREMENT PRIMARY KEY,
    poll_id INT NOT NULL,
    option_text VARCHAR(255) NOT NULL,
    FOREIGN KEY (poll_id) REFERENCES polls(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS poll_votes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    poll_id INT NOT NULL,
    option_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_vote (poll_id, user_id),
    FOREIGN KEY (poll_id) REFERENCES polls(id) ON DELETE CASCADE,
    FOREIGN KEY (option_id) REFERENCES poll_options(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =====================================================
-- NEW MODULE: DOCUMENT CENTER
-- =====================================================

CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT,
    file_name VARCHAR(255),
    file_path VARCHAR(500),
    file_size INT DEFAULT 0,
    uploaded_by INT NOT NULL,
    downloads INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE
);

-- =====================================================
-- NEW MODULE: COMMUNITY DIRECTORY
-- =====================================================

CREATE TABLE IF NOT EXISTS community_directory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    block VARCHAR(10),
    unit VARCHAR(20),
    profession VARCHAR(100),
    skills TEXT,
    bio TEXT,
    show_phone BOOLEAN DEFAULT TRUE,
    show_email BOOLEAN DEFAULT TRUE,
    is_visible BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =====================================================
-- INSERT DEMO DATA
-- =====================================================

-- Demo Users (if not exists)
INSERT IGNORE INTO users (username, email, password, is_admin) VALUES 
('admin', 'admin@smarthub.com', 'admin123', TRUE),
('john_doe', 'john@example.com', 'admin123', FALSE);

-- Demo Marketplace Items
INSERT INTO marketplace (user_id, title, category, description, price, `condition`, contact_phone, image_url, status) VALUES
(2, 'Gaming Laptop - MSI GF63', 'Electronics', 'Excellent gaming laptop, Intel i7, RTX 3050, 16GB RAM. Used for 6 months only. Selling because upgrading.', 85000, 'like_new', '0300-1234567', 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=500&h=300&fit=crop', 'available'),
(1, 'Wooden Study Table', 'Furniture', 'Solid wood study table with 3 drawers. Perfect for home office. Minor scratches.', 15000, 'good', '0321-9876543', 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=500&h=300&fit=crop', 'available');

-- Demo Lost & Found Items
INSERT INTO lost_found (user_id, type, title, category, description, location, date_occurred, contact_phone, image_url, status) VALUES
(2, 'lost', 'Golden Watch - Tissot', 'Jewelry', 'Lost my golden Tissot watch near the community park. It has a brown leather strap and my initials J.D. engraved on the back.', 'Community Park, near Block A', CURDATE(), '0300-1234567', 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=500&h=300&fit=crop', 'open'),
(1, 'found', 'Car Keys with BMW Keychain', 'Keys', 'Found a set of car keys with BMW keychain near the parking lot. Contact to claim with proper identification.', 'Parking Lot B', CURDATE(), '0321-9876543', 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=500&h=300&fit=crop', 'open');

-- Demo Poll
INSERT INTO polls (question, created_by, end_date, status) VALUES
('What should be our next community event?', 1, DATE_ADD(CURDATE(), INTERVAL 7 DAY), 'active');

INSERT INTO poll_options (poll_id, option_text) VALUES
(1, 'BBQ Night'),
(1, 'Movie Screening'),
(1, 'Sports Tournament'),
(1, 'Cultural Festival');

-- Demo Documents
INSERT INTO documents (title, category, description, file_name, file_path, file_size, uploaded_by, downloads) VALUES
('Community Rules & Regulations 2025', 'Rules & Regulations', 'Complete guide to community rules, regulations, and guidelines for all residents.', 'community_rules_2025.pdf', 'uploads/documents/community_rules_2025.pdf', 256000, 1, 15),
('Maintenance Request Form', 'Forms', 'Standard form for submitting maintenance requests to the management office.', 'maintenance_form.pdf', 'uploads/documents/maintenance_form.pdf', 128000, 1, 8);

-- Demo Community Directory Entries
INSERT INTO community_directory (user_id, name, phone, block, unit, profession, skills, bio, show_phone, show_email, is_visible) VALUES
(1, 'Admin User', '0321-1111111', 'A', '101', 'Community Manager', 'Management, Event Planning, Conflict Resolution', 'Your friendly community manager. Always here to help!', TRUE, TRUE, TRUE),
(2, 'John Doe', '0300-1234567', 'B', '205', 'Software Engineer', 'Web Development, Python, JavaScript, Tech Support', 'Tech enthusiast and problem solver. Happy to help with any tech issues!', TRUE, TRUE, TRUE);

-- =====================================================
-- DONE! Your database is ready.
-- =====================================================
