<?php
// Get current page for active state
$currentPage = basename($_SERVER['PHP_SELF']);
$user = getCurrentUser();

// Group pages for active state
$marketplacePages = ['marketplace.php', 'add-listing.php', 'listing-detail.php'];
$lostFoundPages = ['lost-found.php', 'add-lost-found.php', 'lost-found-detail.php'];
$pollPages = ['polls.php', 'create-poll.php', 'vote-poll.php'];
$documentPages = ['documents.php', 'upload-document.php'];
$directoryPages = ['directory.php', 'add-profile.php', 'edit-profile.php', 'member-profile.php'];
$complaintPages = ['add-complaint.php', 'admin-complaints.php'];
$faqPages = ['faqs.php', 'manage-faqs.php', 'ask-question.php', 'admin-questions.php'];
?>

<nav>
    <div class="nav-container">
        <div class="logo">🚀 SmartHub</div>
        <ul>
            <li><a href="index.php" <?= $currentPage == 'index.php' ? 'class="active"' : ''; ?>>Events</a></li>
            <li><a href="announcements.php" <?= $currentPage == 'announcements.php' || $currentPage == 'announcement-detail.php' ? 'class="active"' : ''; ?>>Announcements</a></li>
            <li><a href="marketplace.php" <?= in_array($currentPage, $marketplacePages) ? 'class="active"' : ''; ?>>Marketplace</a></li>
            <li><a href="lost-found.php" <?= in_array($currentPage, $lostFoundPages) ? 'class="active"' : ''; ?>>Lost & Found</a></li>
            <li><a href="polls.php" <?= in_array($currentPage, $pollPages) ? 'class="active"' : ''; ?>>Polls</a></li>
            <li><a href="documents.php" <?= in_array($currentPage, $documentPages) ? 'class="active"' : ''; ?>>Documents</a></li>
            <li><a href="directory.php" <?= in_array($currentPage, $directoryPages) ? 'class="active"' : ''; ?>>Directory</a></li>
            <li><a href="faqs.php" <?= in_array($currentPage, $faqPages) ? 'class="active"' : ''; ?>>FAQs</a></li>
            <li><a href="<?= isAdmin() ? 'admin-complaints.php' : 'add-complaint.php'; ?>" <?= in_array($currentPage, $complaintPages) ? 'class="active"' : ''; ?>>Complaints</a></li>
            
            <li style="margin-left: auto; display: flex; align-items: center; gap: 1rem;">
                <span style="color: var(--secondary);">Welcome, <strong><?= htmlspecialchars($user['username']); ?></strong></span>
                <a href="logout.php" class="btn btn-small" style="margin: 0;">Logout</a>
            </li>
        </ul>
    </div>
</nav>
