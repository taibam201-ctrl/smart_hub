<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$type = isset($_GET['type']) ? $_GET['type'] : 'lost';
if (!in_array($type, ['lost', 'found'])) $type = 'lost';

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $conn->real_escape_string($_POST['title'] ?? '');
    $type = $conn->real_escape_string($_POST['type'] ?? 'lost');
    $category = $conn->real_escape_string($_POST['category'] ?? '');
    $description = $conn->real_escape_string($_POST['description'] ?? '');
    $location = $conn->real_escape_string($_POST['location'] ?? '');
    $date_occurred = $conn->real_escape_string($_POST['date_occurred'] ?? date('Y-m-d'));
    $contact_phone = $conn->real_escape_string($_POST['contact_phone'] ?? '');
    $userId = $user['id'];

    $imageUrl = 'https://images.unsplash.com/photo-1586769852044-692d6e3703f0?w=500&h=300&fit=crop';

    if ($title && $category && $description && $location) {
        $sql = "INSERT INTO lost_found (user_id, type, title, category, description, location, date_occurred, contact_phone, image_url, status)
                VALUES ($userId, '$type', '$title', '$category', '$description', '$location', '$date_occurred', '$contact_phone', '$imageUrl', 'open')";
        
        if ($conn->query($sql)) {
            $message = "Item reported successfully!";
            $messageType = "success";
        } else {
            $message = "Error: " . $conn->error;
            $messageType = "error";
        }
    } else {
        $message = "Please fill all required fields!";
        $messageType = "error";
    }
}

$isLost = $type === 'lost';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report <?= $isLost ? 'Lost' : 'Found'; ?> Item - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero" style="background: linear-gradient(135deg, <?= $isLost ? 'rgba(239, 68, 68, 0.2), rgba(220, 38, 38, 0.2)' : 'rgba(16, 185, 129, 0.2), rgba(5, 150, 105, 0.2)'; ?>);">
            <h1><?= $isLost ? '🚨 Report Lost Item' : '✅ Report Found Item'; ?></h1>
            <p><?= $isLost ? 'Describe the item you lost and where you last saw it' : 'Help reunite this item with its owner'; ?></p>
        </div>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>">
                <?= $message ?>
                <?php if ($messageType === 'success'): ?>
                    <br><a href="lost-found.php" style="color: inherit; text-decoration: underline;">View All Items</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST">
                <input type="hidden" name="type" value="<?= $type; ?>">

                <div class="form-group">
                    <label>Item Name *</label>
                    <input type="text" name="title" placeholder="e.g., Blue Wallet, Golden Watch, Car Keys" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div class="form-group">
                        <label>Category *</label>
                        <select name="category" required>
                            <option value="">Select Category</option>
                            <option value="Electronics">Electronics</option>
                            <option value="Wallet/Purse">Wallet/Purse</option>
                            <option value="Keys">Keys</option>
                            <option value="Documents">Documents</option>
                            <option value="Jewelry">Jewelry</option>
                            <option value="Clothing">Clothing</option>
                            <option value="Bags">Bags</option>
                            <option value="Pets">Pets</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Date <?= $isLost ? 'Lost' : 'Found'; ?> *</label>
                        <input type="date" name="date_occurred" value="<?= date('Y-m-d'); ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Location (<?= $isLost ? 'Last seen' : 'Where found'; ?>) *</label>
                    <input type="text" name="location" placeholder="e.g., Block A, near main gate, parking lot" required>
                </div>

                <div class="form-group">
                    <label>Contact Phone *</label>
                    <input type="tel" name="contact_phone" placeholder="Your phone number" required>
                </div>

                <div class="form-group">
                    <label>Description *</label>
                    <textarea name="description" placeholder="Provide as much detail as possible - color, size, brand, distinguishing features..." required style="min-height: 150px;"></textarea>
                </div>

                <div style="display: flex; gap: 1rem;">
                    <button type="submit" class="btn" style="background: linear-gradient(135deg, <?= $isLost ? '#ef4444, #dc2626' : '#10b981, #059669'; ?>);">
                        Submit Report
                    </button>
                    <a href="lost-found.php" class="btn" style="background: rgba(255,255,255,0.1);">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
