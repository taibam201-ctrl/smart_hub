<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

require 'config.php';
requireLogin();

$user = getCurrentUser();
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = $conn->real_escape_string($_POST['title']);
    $category = $conn->real_escape_string($_POST['category']);
    $description = $conn->real_escape_string($_POST['description']);
    $user_id = $user['id'];

    if ($title && $category && $description) {

        $sql = "INSERT INTO complaints (user_id, title, category, description)
                VALUES ($user_id, '$title', '$category', '$description')";
        
        if ($conn->query($sql)) {
            $message = "Complaint submitted successfully!";
            $messageType = "success";
        } else {
            $message = "Error: " . $conn->error;
            $messageType = "error";
        }

    } else {
        $message = "Please fill all fields!";
        $messageType = "error";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Submit Complaint - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<nav>
    <div class="nav-container">
        <div class="logo">🚀 SmartHub</div>
        <ul>
            <li><a href="index.php">Create Event</a></li>
            <li><a href="events.php">Browse Events</a></li>
            <li><a href="announcements.php">Announcements</a></li>
            <li><a href="add-complaint.php" class="active">Add Complaint</a></li>
            <li><a href="complaints.php">My Complaints</a></li>

            <li style="margin-left:auto;">
                <span>Welcome, <strong><?= htmlspecialchars($user['username']); ?></strong></span>
                <a href="logout.php" class="btn btn-small">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container">

    <div class="hero">
        <h1>Submit a Complaint</h1>
        <p>Tell us your issue and we will take care of it</p>
    </div>

    <?php if ($message): ?>
        <div class="message <?= $messageType ?>"><?= $message ?></div>
    <?php endif; ?>

    <div class="form-container">
        <form method="POST">
            <div class="form-group">
                <label>Complaint Title *</label>
                <input type="text" name="title" required>
            </div>

            <div class="form-group">
                <label>Category *</label>
                <select name="category" required>
                    <option value="">Select Category</option>
                    <option value="Maintenance">Maintenance</option>
                    <option value="Security">Security</option>
                    <option value="Water Supply">Water Supply</option>
                    <option value="Electricity">Electricity</option>
                    <option value="Cleanliness">Cleanliness</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="form-group">
                <label>Description *</label>
                <textarea name="description" required></textarea>
            </div>

            <button type="submit" class="btn">Submit Complaint</button>
        </form>
    </div>

</div>

</body>
</html>
