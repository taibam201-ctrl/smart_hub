<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$pollId = (int)($_GET['id'] ?? 0);

if (!$pollId) {
    header('Location: polls.php');
    exit();
}

// Get poll info
$sql = "SELECT p.*, u.username FROM polls p JOIN users u ON p.created_by = u.id WHERE p.id = $pollId";
$result = $conn->query($sql);

if (!$result || $result->num_rows === 0) {
    header('Location: polls.php');
    exit();
}

$poll = $result->fetch_assoc();

// Check if poll is closed
$isClosed = $poll['status'] === 'closed' || ($poll['end_date'] && strtotime($poll['end_date']) < time());

// Check if user already voted
$voteCheck = $conn->query("SELECT * FROM poll_votes WHERE poll_id = $pollId AND user_id = {$user['id']}");
$hasVoted = $voteCheck && $voteCheck->num_rows > 0;

// Handle vote submission
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['option_id']) && !$hasVoted && !$isClosed) {
    $optionId = (int)$_POST['option_id'];
    
    // Verify option belongs to this poll
    $optCheck = $conn->query("SELECT * FROM poll_options WHERE id = $optionId AND poll_id = $pollId");
    if ($optCheck && $optCheck->num_rows > 0) {
        $sql = "INSERT INTO poll_votes (poll_id, option_id, user_id) VALUES ($pollId, $optionId, {$user['id']})";
        if ($conn->query($sql)) {
            $hasVoted = true;
            $message = "Vote submitted successfully!";
            $messageType = "success";
        }
    }
}

// Get options with vote counts
$optionsSql = "SELECT po.*, 
               (SELECT COUNT(*) FROM poll_votes pv WHERE pv.option_id = po.id) as vote_count
               FROM poll_options po 
               WHERE po.poll_id = $pollId 
               ORDER BY po.id";
$optionsResult = $conn->query($optionsSql);
$options = $optionsResult ? $optionsResult->fetch_all(MYSQLI_ASSOC) : [];

// Calculate total votes
$totalVotes = array_sum(array_column($options, 'vote_count'));

// Get user's vote
$userVote = null;
if ($hasVoted) {
    $userVoteResult = $conn->query("SELECT option_id FROM poll_votes WHERE poll_id = $pollId AND user_id = {$user['id']}");
    if ($userVoteResult && $userVoteResult->num_rows > 0) {
        $userVote = $userVoteResult->fetch_assoc()['option_id'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($poll['question']); ?> - Poll</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .poll-option {
            background: rgba(124, 58, 237, 0.1);
            border: 2px solid rgba(124, 58, 237, 0.3);
            border-radius: 12px;
            padding: 1rem 1.5rem;
            margin-bottom: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .poll-option:hover {
            border-color: var(--secondary);
            background: rgba(124, 58, 237, 0.2);
        }
        .poll-option.selected {
            border-color: var(--secondary);
            background: rgba(6, 182, 212, 0.2);
        }
        .poll-option.voted {
            cursor: default;
        }
        .poll-option input[type="radio"] {
            display: none;
        }
        .vote-bar {
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            background: linear-gradient(90deg, rgba(124, 58, 237, 0.3), rgba(6, 182, 212, 0.3));
            transition: width 0.5s ease;
            z-index: 0;
        }
        .option-content {
            position: relative;
            z-index: 1;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .user-voted {
            background: var(--secondary);
            color: var(--dark);
            padding: 0.2rem 0.5rem;
            border-radius: 5px;
            font-size: 0.75rem;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <?php if ($message): ?>
            <div class="message <?= $messageType ?>"><?= $message ?></div>
        <?php endif; ?>

        <div style="max-width: 700px; margin: 0 auto;">
            <div style="background: var(--glass); border: 1px solid rgba(124,58,237,0.3); border-radius: 20px; padding: 2rem;">
                
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
                    <span style="background: <?= $isClosed ? 'rgba(255,255,255,0.2)' : 'linear-gradient(135deg, var(--primary), var(--secondary))'; ?>; padding: 0.4rem 1rem; border-radius: 20px; font-weight: 700;">
                        <?= $isClosed ? '🔒 Closed' : '🗳️ Active'; ?>
                    </span>
                    <span style="opacity: 0.7;"><?= $totalVotes; ?> total votes</span>
                </div>

                <h1 style="font-size: 1.8rem; margin-bottom: 1rem;"><?= htmlspecialchars($poll['question']); ?></h1>
                
                <div style="display: flex; gap: 2rem; margin-bottom: 2rem; opacity: 0.8; font-size: 0.9rem; flex-wrap: wrap;">
                    <span>👤 By <?= htmlspecialchars($poll['username']); ?></span>
                    <span>📅 <?= date('M d, Y', strtotime($poll['created_at'])); ?></span>
                    <?php if ($poll['end_date']): ?>
                        <span>⏰ <?= $isClosed ? 'Ended' : 'Ends'; ?> <?= date('M d, Y', strtotime($poll['end_date'])); ?></span>
                    <?php endif; ?>
                </div>

                <?php if (!$hasVoted && !$isClosed): ?>
                    <form method="POST">
                        <?php foreach ($options as $option): ?>
                            <label class="poll-option">
                                <input type="radio" name="option_id" value="<?= $option['id']; ?>" required>
                                <div class="option-content">
                                    <span style="font-weight: 600;"><?= htmlspecialchars($option['option_text']); ?></span>
                                </div>
                            </label>
                        <?php endforeach; ?>
                        
                        <button type="submit" class="btn" style="width: 100%; margin-top: 1rem;">Submit Vote</button>
                    </form>
                <?php else: ?>
                    <!-- Show Results -->
                    <?php foreach ($options as $option): 
                        $percentage = $totalVotes > 0 ? round(($option['vote_count'] / $totalVotes) * 100) : 0;
                        $isUserVote = $userVote == $option['id'];
                    ?>
                        <div class="poll-option voted" style="<?= $isUserVote ? 'border-color: var(--secondary);' : ''; ?>">
                            <div class="vote-bar" style="width: <?= $percentage; ?>%;"></div>
                            <div class="option-content">
                                <span style="font-weight: 600;">
                                    <?= htmlspecialchars($option['option_text']); ?>
                                    <?php if ($isUserVote): ?>
                                        <span class="user-voted">Your Vote</span>
                                    <?php endif; ?>
                                </span>
                                <span style="font-weight: 700;">
                                    <?= $percentage; ?>% 
                                    <small style="opacity: 0.7;">(<?= $option['vote_count']; ?>)</small>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    
                    <?php if ($hasVoted): ?>
                        <p style="text-align: center; margin-top: 1.5rem; opacity: 0.8;">
                            ✅ You have already voted in this poll
                        </p>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if (isAdmin() && !$isClosed): ?>
                    <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid rgba(124,58,237,0.3);">
                        <a href="close-poll.php?id=<?= $pollId; ?>" class="btn btn-small btn-danger" onclick="return confirm('Close this poll? This cannot be undone.');">
                            🔒 Close Poll
                        </a>
                    </div>
                <?php endif; ?>

                <a href="polls.php" class="btn" style="margin-top: 2rem; background: rgba(255,255,255,0.1);">← Back to Polls</a>
            </div>
        </div>
    </div>

    <script>
        // Add selected state to radio options
        document.querySelectorAll('.poll-option input[type="radio"]').forEach(radio => {
            radio.addEventListener('change', function() {
                document.querySelectorAll('.poll-option').forEach(opt => opt.classList.remove('selected'));
                this.closest('.poll-option').classList.add('selected');
            });
        });
    </script>
</body>
</html>
