<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$categoryFilter = isset($_GET['category']) ? $conn->real_escape_string($_GET['category']) : '';
$searchTerm = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$sql = "SELECT f.*, u.username FROM faqs f JOIN users u ON f.created_by = u.id WHERE f.is_published = 1";

if ($categoryFilter) {
    $sql .= " AND f.category = '$categoryFilter'";
}

if ($searchTerm) {
    $sql .= " AND (f.question LIKE '%$searchTerm%' OR f.answer LIKE '%$searchTerm%')";
}

$sql .= " ORDER BY f.is_pinned DESC, f.sort_order ASC, f.created_at DESC";

$result = $conn->query($sql);
$faqs = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Group FAQs by category
$faqsByCategory = [];
foreach ($faqs as $faq) {
    $faqsByCategory[$faq['category']][] = $faq;
}

$categories = [
    'General' => '📌',
    'Events' => '🎉',
    'Payments' => '💳',
    'Facilities' => '🏢',
    'Rules' => '📋',
    'Maintenance' => '🔧',
    'Security' => '🔒',
    'Other' => '❓'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQs - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .faq-item {
            background: var(--glass);
            border: 1px solid rgba(124, 58, 237, 0.3);
            border-radius: 16px;
            margin-bottom: 1rem;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        .faq-item:hover {
            border-color: var(--secondary);
        }
        .faq-question {
            padding: 1.2rem 1.5rem;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 600;
            font-size: 1.05rem;
        }
        .faq-question:hover {
            background: rgba(124, 58, 237, 0.1);
        }
        .faq-toggle {
            font-size: 1.5rem;
            transition: transform 0.3s ease;
            color: var(--secondary);
        }
        .faq-item.active .faq-toggle {
            transform: rotate(45deg);
        }
        .faq-answer {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease, padding 0.3s ease;
            padding: 0 1.5rem;
            line-height: 1.7;
            color: rgba(226, 232, 240, 0.85);
        }
        .faq-item.active .faq-answer {
            max-height: 500px;
            padding: 0 1.5rem 1.5rem;
        }
        .faq-meta {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid rgba(124, 58, 237, 0.2);
            font-size: 0.8rem;
            opacity: 0.6;
        }
        .category-section {
            margin-bottom: 2.5rem;
        }
        .category-title {
            font-size: 1.3rem;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid rgba(124, 58, 237, 0.3);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .pinned-badge {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            padding: 0.2rem 0.6rem;
            border-radius: 10px;
            font-size: 0.7rem;
            font-weight: 700;
            margin-left: 0.5rem;
        }
    </style>
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>❓ Frequently Asked Questions</h1>
            <p>Find answers to common questions about our community</p>
        </div>

        <?php if (isAdmin()): ?>
            <div style="text-align: right; margin-bottom: 1.5rem;">
                <a href="manage-faqs.php" class="btn">⚙️ Manage FAQs</a>
            </div>
        <?php endif; ?>

        <div class="search-filter">
            <form method="GET" style="display: contents;">
                <input type="text" name="search" placeholder="Search FAQs..." value="<?= htmlspecialchars($searchTerm); ?>">
                
                <select name="category">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat => $icon): ?>
                        <option value="<?= $cat; ?>" <?= $categoryFilter === $cat ? 'selected' : ''; ?>>
                            <?= $icon . ' ' . $cat; ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <button type="submit" class="btn btn-small">Search</button>
            </form>
        </div>

        <?php if (count($faqs) > 0): ?>
            <?php if ($categoryFilter || $searchTerm): ?>
                <!-- Show flat list when filtering -->
                <div class="category-section">
                    <?php foreach ($faqs as $faq): ?>
                        <div class="faq-item">
                            <div class="faq-question" onclick="toggleFaq(this)">
                                <span>
                                    <?= htmlspecialchars($faq['question']); ?>
                                    <?php if ($faq['is_pinned']): ?>
                                        <span class="pinned-badge">📌 Pinned</span>
                                    <?php endif; ?>
                                </span>
                                <span class="faq-toggle">+</span>
                            </div>
                            <div class="faq-answer">
                                <?= nl2br(htmlspecialchars($faq['answer'])); ?>
                                <div class="faq-meta">
                                    <span>📁 <?= htmlspecialchars($faq['category']); ?></span>
                                    <span>👤 <?= htmlspecialchars($faq['username']); ?></span>
                                    <span>📅 <?= date('M d, Y', strtotime($faq['created_at'])); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <!-- Show grouped by category -->
                <?php foreach ($faqsByCategory as $category => $categoryFaqs): ?>
                    <div class="category-section">
                        <h2 class="category-title">
                            <?= $categories[$category] ?? '❓'; ?> <?= htmlspecialchars($category); ?>
                            <span style="font-size: 0.9rem; opacity: 0.6; font-weight: normal;">(<?= count($categoryFaqs); ?>)</span>
                        </h2>
                        <?php foreach ($categoryFaqs as $faq): ?>
                            <div class="faq-item">
                                <div class="faq-question" onclick="toggleFaq(this)">
                                    <span>
                                        <?= htmlspecialchars($faq['question']); ?>
                                        <?php if ($faq['is_pinned']): ?>
                                            <span class="pinned-badge">📌 Pinned</span>
                                        <?php endif; ?>
                                    </span>
                                    <span class="faq-toggle">+</span>
                                </div>
                                <div class="faq-answer">
                                    <?= nl2br(htmlspecialchars($faq['answer'])); ?>
                                    <div class="faq-meta">
                                        <span>👤 <?= htmlspecialchars($faq['username']); ?></span>
                                        <span>📅 <?= date('M d, Y', strtotime($faq['created_at'])); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        <?php else: ?>
            <div class="empty-state">
                <h3>No FAQs Found</h3>
                <p>No frequently asked questions have been added yet<?= $searchTerm ? ' matching your search' : ''; ?>.</p>
                <?php if ($searchTerm || $categoryFilter): ?>
                    <a href="faqs.php" class="btn">Clear Filters</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- Ask a Question Section -->
        <div style="margin-top: 3rem; background: var(--glass); border: 1px solid rgba(124,58,237,0.3); border-radius: 20px; padding: 2rem; text-align: center;">
            <h3 style="margin-bottom: 0.5rem;">Can't find what you're looking for?</h3>
            <p style="opacity: 0.8; margin-bottom: 1.5rem;">Submit your question and we'll get back to you soon.</p>
            <a href="ask-question.php" class="btn">💬 Ask a Question</a>
        </div>
    </div>

    <script>
        function toggleFaq(element) {
            const faqItem = element.parentElement;
            const isActive = faqItem.classList.contains('active');
            
            // Close all other FAQs (optional - remove this loop for multiple open)
            // document.querySelectorAll('.faq-item').forEach(item => item.classList.remove('active'));
            
            if (isActive) {
                faqItem.classList.remove('active');
            } else {
                faqItem.classList.add('active');
            }
        }

        // Open FAQ if linked with hash
        window.onload = function() {
            const hash = window.location.hash;
            if (hash) {
                const faq = document.querySelector(hash);
                if (faq) {
                    faq.classList.add('active');
                    faq.scrollIntoView({ behavior: 'smooth' });
                }
            }
        }
    </script>
</body>
</html>
