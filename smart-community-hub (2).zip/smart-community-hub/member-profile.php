<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$profileId = (int)($_GET['id'] ?? 0);

if (!$profileId) {
    header('Location: directory.php');
    exit();
}

$sql = "SELECT cd.*, u.email FROM community_directory cd LEFT JOIN users u ON cd.user_id = u.id WHERE cd.id = $profileId AND cd.is_visible = 1";
$result = $conn->query($sql);

if (!$result || $result->num_rows === 0) {
    header('Location: directory.php');
    exit();
}

$member = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($member['name']); ?> - Community Directory</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div style="max-width: 700px; margin: 0 auto;">
            <div style="background: var(--glass); border: 1px solid rgba(124,58,237,0.3); border-radius: 20px; padding: 2.5rem; text-align: center;">
                
                <div style="width: 120px; height: 120px; background: linear-gradient(135deg, var(--primary), var(--secondary)); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 3rem; font-weight: 700; margin: 0 auto 1.5rem;">
                    <?= strtoupper(substr($member['name'], 0, 1)); ?>
                </div>
                
                <h1 style="font-size: 2rem; margin-bottom: 0.5rem;"><?= htmlspecialchars($member['name']); ?></h1>
                
                <?php if ($member['profession']): ?>
                    <p style="font-size: 1.2rem; color: var(--secondary); margin-bottom: 1.5rem;">
                        <?= htmlspecialchars($member['profession']); ?>
                    </p>
                <?php endif; ?>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin: 2rem 0; text-align: left;">
                    <?php if ($member['block']): ?>
                        <div style="background: rgba(124,58,237,0.1); padding: 1rem; border-radius: 10px;">
                            <small style="opacity: 0.7;">🏠 Location</small>
                            <p style="margin: 0.3rem 0 0; font-weight: 600;">
                                Block <?= htmlspecialchars($member['block']); ?><?= $member['unit'] ? ', Unit ' . htmlspecialchars($member['unit']) : ''; ?>
                            </p>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($member['phone'] && $member['show_phone']): ?>
                        <div style="background: rgba(124,58,237,0.1); padding: 1rem; border-radius: 10px;">
                            <small style="opacity: 0.7;">📞 Phone</small>
                            <p style="margin: 0.3rem 0 0; font-weight: 600;">
                                <a href="tel:<?= htmlspecialchars($member['phone']); ?>" style="color: var(--secondary); text-decoration: none;">
                                    <?= htmlspecialchars($member['phone']); ?>
                                </a>
                            </p>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($member['email'] && $member['show_email']): ?>
                        <div style="background: rgba(124,58,237,0.1); padding: 1rem; border-radius: 10px;">
                            <small style="opacity: 0.7;">📧 Email</small>
                            <p style="margin: 0.3rem 0 0; font-weight: 600; word-break: break-all;">
                                <a href="mailto:<?= htmlspecialchars($member['email']); ?>" style="color: var(--secondary); text-decoration: none;">
                                    <?= htmlspecialchars($member['email']); ?>
                                </a>
                            </p>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ($member['skills']): ?>
                    <div style="text-align: left; margin: 2rem 0; padding: 1.5rem; background: rgba(6, 182, 212, 0.1); border-radius: 12px;">
                        <h3 style="margin-bottom: 0.8rem;">🛠️ Skills & Expertise</h3>
                        <p style="margin: 0; line-height: 1.6;"><?= htmlspecialchars($member['skills']); ?></p>
                    </div>
                <?php endif; ?>

                <?php if ($member['bio']): ?>
                    <div style="text-align: left; margin: 2rem 0;">
                        <h3 style="margin-bottom: 0.8rem;">📝 About</h3>
                        <p style="line-height: 1.8; opacity: 0.9;"><?= nl2br(htmlspecialchars($member['bio'])); ?></p>
                    </div>
                <?php endif; ?>

                <a href="directory.php" class="btn" style="margin-top: 1rem;">← Back to Directory</a>
            </div>
        </div>
    </div>
</body>
</html>
