<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$typeFilter = isset($_GET['type']) ? $conn->real_escape_string($_GET['type']) : '';
$searchTerm = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$sql = "SELECT lf.*, u.username FROM lost_found lf JOIN users u ON lf.user_id = u.id WHERE lf.status = 'open'";

if ($typeFilter) {
    $sql .= " AND lf.type = '$typeFilter'";
}

if ($searchTerm) {
    $sql .= " AND (lf.title LIKE '%$searchTerm%' OR lf.description LIKE '%$searchTerm%' OR lf.location LIKE '%$searchTerm%')";
}

$sql .= " ORDER BY lf.created_at DESC";

$result = $conn->query($sql);
$items = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lost & Found - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>🔍 Lost & Found</h1>
            <p>Help reunite lost items with their owners or find what you've lost</p>
        </div>

        <div style="display: flex; justify-content: center; gap: 1rem; margin-bottom: 2rem; flex-wrap: wrap;">
            <a href="add-lost-found.php?type=lost" class="btn" style="background: linear-gradient(135deg, #ef4444, #dc2626);">
                🚨 Report Lost Item
            </a>
            <a href="add-lost-found.php?type=found" class="btn" style="background: linear-gradient(135deg, #10b981, #059669);">
                ✅ Report Found Item
            </a>
        </div>

        <div class="search-filter">
            <form method="GET" style="display: contents;">
                <input type="text" name="search" placeholder="Search by item name or location..." value="<?= htmlspecialchars($searchTerm); ?>">
                
                <select name="type">
                    <option value="">All Items</option>
                    <option value="lost" <?= $typeFilter === 'lost' ? 'selected' : ''; ?>>🚨 Lost Items</option>
                    <option value="found" <?= $typeFilter === 'found' ? 'selected' : ''; ?>>✅ Found Items</option>
                </select>

                <button type="submit" class="btn btn-small">Search</button>
            </form>
        </div>

        <?php if (count($items) > 0): ?>
            <div class="grid">
                <?php foreach ($items as $item): ?>
                    <div class="event-card" style="border-color: <?= $item['type'] === 'lost' ? 'rgba(239, 68, 68, 0.5)' : 'rgba(16, 185, 129, 0.5)'; ?>;">
                        <div class="event-image">
                            <img src="<?= htmlspecialchars($item['image_url'] ?: 'https://images.unsplash.com/photo-1586769852044-692d6e3703f0?w=500&h=300&fit=crop'); ?>" alt="<?= htmlspecialchars($item['title']); ?>">
                            <div class="event-badge" style="background: <?= $item['type'] === 'lost' ? 'linear-gradient(135deg, #ef4444, #dc2626)' : 'linear-gradient(135deg, #10b981, #059669)'; ?>;">
                                <?= $item['type'] === 'lost' ? '🚨 LOST' : '✅ FOUND'; ?>
                            </div>
                        </div>
                        <div class="event-info">
                            <h3 class="event-title"><?= htmlspecialchars($item['title']); ?></h3>
                            <div class="event-details">
                                <div class="event-detail-row">
                                    <span class="event-detail-icon">📍</span>
                                    <span><?= htmlspecialchars($item['location']); ?></span>
                                </div>
                                <div class="event-detail-row">
                                    <span class="event-detail-icon">📅</span>
                                    <span><?= date('M d, Y', strtotime($item['date_occurred'])); ?></span>
                                </div>
                                <div class="event-detail-row">
                                    <span class="event-detail-icon">👤</span>
                                    <span>Posted by <?= htmlspecialchars($item['username']); ?></span>
                                </div>
                            </div>
                            <p class="event-description"><?= substr(htmlspecialchars($item['description']), 0, 100); ?>...</p>
                            <div class="event-footer">
                                <span style="color: rgba(226, 232, 240, 0.6); font-size: 0.85rem;">
                                    <?= date('M d', strtotime($item['created_at'])); ?>
                                </span>
                                <a href="lost-found-detail.php?id=<?= $item['id']; ?>" class="btn btn-small">View Details</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h3>No Items Reported</h3>
                <p>No lost or found items have been reported yet.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
