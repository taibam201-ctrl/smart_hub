<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$searchTerm = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$blockFilter = isset($_GET['block']) ? $conn->real_escape_string($_GET['block']) : '';

$sql = "SELECT cd.*, u.username, u.email 
        FROM community_directory cd 
        LEFT JOIN users u ON cd.user_id = u.id 
        WHERE cd.is_visible = 1";

if ($searchTerm) {
    $sql .= " AND (cd.name LIKE '%$searchTerm%' OR cd.profession LIKE '%$searchTerm%' OR cd.skills LIKE '%$searchTerm%')";
}

if ($blockFilter) {
    $sql .= " AND cd.block = '$blockFilter'";
}

$sql .= " ORDER BY cd.name ASC";

$result = $conn->query($sql);
$members = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

$profileCheck = $conn->query("SELECT * FROM community_directory WHERE user_id = {$user['id']}");
$hasProfile = $profileCheck && $profileCheck->num_rows > 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Directory - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>👥 Community Directory</h1>
            <p>Connect with your neighbors and community members</p>
        </div>

        <div style="text-align: right; margin-bottom: 1.5rem;">
            <a href="<?= $hasProfile ? 'edit-profile.php' : 'add-profile.php'; ?>" class="btn">
                <?= $hasProfile ? '✏️ Edit My Profile' : '+ Add My Profile'; ?>
            </a>
        </div>

        <div class="search-filter">
            <form method="GET" style="display: contents;">
                <input type="text" name="search" placeholder="Search by name, profession, or skills..." value="<?= htmlspecialchars($searchTerm); ?>">
                
                <select name="block">
                    <option value="">All Blocks</option>
                    <option value="A" <?= $blockFilter === 'A' ? 'selected' : ''; ?>>Block A</option>
                    <option value="B" <?= $blockFilter === 'B' ? 'selected' : ''; ?>>Block B</option>
                    <option value="C" <?= $blockFilter === 'C' ? 'selected' : ''; ?>>Block C</option>
                    <option value="D" <?= $blockFilter === 'D' ? 'selected' : ''; ?>>Block D</option>
                    <option value="E" <?= $blockFilter === 'E' ? 'selected' : ''; ?>>Block E</option>
                </select>

                <button type="submit" class="btn btn-small">Search</button>
            </form>
        </div>

        <?php if (count($members) > 0): ?>
            <div class="grid">
                <?php foreach ($members as $member): ?>
                    <div class="event-card">
                        <div class="event-info" style="padding: 1.5rem;">
                            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                                <div style="width: 60px; height: 60px; background: linear-gradient(135deg, var(--primary), var(--secondary)); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: 700; flex-shrink: 0;">
                                    <?= strtoupper(substr($member['name'], 0, 1)); ?>
                                </div>
                                <div>
                                    <h3 style="margin: 0; font-size: 1.2rem;"><?= htmlspecialchars($member['name']); ?></h3>
                                    <?php if ($member['profession']): ?>
                                        <p style="margin: 0; font-size: 0.9rem; color: var(--secondary);"><?= htmlspecialchars($member['profession']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="event-details">
                                <?php if ($member['block']): ?>
                                    <div class="event-detail-row">
                                        <span class="event-detail-icon">🏠</span>
                                        <span>Block <?= htmlspecialchars($member['block']); ?><?= $member['unit'] ? ', Unit ' . htmlspecialchars($member['unit']) : ''; ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if ($member['phone'] && $member['show_phone']): ?>
                                    <div class="event-detail-row">
                                        <span class="event-detail-icon">📞</span>
                                        <span><?= htmlspecialchars($member['phone']); ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if ($member['email'] && $member['show_email']): ?>
                                    <div class="event-detail-row">
                                        <span class="event-detail-icon">📧</span>
                                        <span style="font-size: 0.85rem;"><?= htmlspecialchars($member['email']); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($member['skills']): ?>
                                <div style="margin-top: 1rem;">
                                    <small style="opacity: 0.7;">Skills:</small>
                                    <p style="margin: 0.3rem 0 0; font-size: 0.9rem;"><?= htmlspecialchars($member['skills']); ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($member['bio']): ?>
                                <p class="event-description" style="margin-top: 1rem;"><?= substr(htmlspecialchars($member['bio']), 0, 100); ?>...</p>
                            <?php endif; ?>
                            
                            <div class="event-footer" style="margin-top: 1rem;">
                                <a href="member-profile.php?id=<?= $member['id']; ?>" class="btn btn-small" style="width: 100%;">View Profile</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h3>No Members Found</h3>
                <p>No community members have added their profiles yet<?= $searchTerm ? ' matching your search' : ''; ?>.</p>
                <?php if (!$hasProfile): ?>
                    <a href="add-profile.php" class="btn">Be the First!</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
