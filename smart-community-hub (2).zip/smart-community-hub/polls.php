<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();

// Get active polls
$sql = "SELECT p.*, u.username,
        (SELECT COUNT(*) FROM poll_votes pv WHERE pv.poll_id = p.id) as total_votes
        FROM polls p 
        JOIN users u ON p.created_by = u.id 
        WHERE p.status = 'active' AND (p.end_date IS NULL OR p.end_date >= CURDATE())
        ORDER BY p.created_at DESC";

$result = $conn->query($sql);
$activePolls = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Get closed polls
$sqlClosed = "SELECT p.*, u.username,
              (SELECT COUNT(*) FROM poll_votes pv WHERE pv.poll_id = p.id) as total_votes
              FROM polls p 
              JOIN users u ON p.created_by = u.id 
              WHERE p.status = 'closed' OR (p.end_date IS NOT NULL AND p.end_date < CURDATE())
              ORDER BY p.created_at DESC LIMIT 10";

$resultClosed = $conn->query($sqlClosed);
$closedPolls = $resultClosed ? $resultClosed->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Polls - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>📊 Community Polls</h1>
            <p>Vote on community decisions and make your voice heard</p>
        </div>

        <?php if (isAdmin()): ?>
            <div style="text-align: right; margin-bottom: 1.5rem;">
                <a href="create-poll.php" class="btn">+ Create New Poll</a>
            </div>
        <?php endif; ?>

        <h2 style="margin-bottom: 1.5rem; font-size: 1.5rem;">🔥 Active Polls</h2>

        <?php if (count($activePolls) > 0): ?>
            <div class="grid">
                <?php foreach ($activePolls as $poll): 
                    // Check if user already voted
                    $voteCheck = $conn->query("SELECT * FROM poll_votes WHERE poll_id = {$poll['id']} AND user_id = {$user['id']}");
                    $hasVoted = $voteCheck && $voteCheck->num_rows > 0;
                ?>
                    <div class="event-card">
                        <div class="event-info" style="padding: 1.5rem;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                                <span style="background: linear-gradient(135deg, var(--primary), var(--secondary)); padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.8rem; font-weight: 700;">
                                    <?= $hasVoted ? '✅ Voted' : '🗳️ Active'; ?>
                                </span>
                                <span style="font-size: 0.85rem; opacity: 0.7;">
                                    <?= $poll['total_votes']; ?> votes
                                </span>
                            </div>
                            
                            <h3 class="event-title"><?= htmlspecialchars($poll['question']); ?></h3>
                            
                            <div class="event-details">
                                <div class="event-detail-row">
                                    <span class="event-detail-icon">👤</span>
                                    <span>By <?= htmlspecialchars($poll['username']); ?></span>
                                </div>
                                <?php if ($poll['end_date']): ?>
                                    <div class="event-detail-row">
                                        <span class="event-detail-icon">⏰</span>
                                        <span>Ends <?= date('M d, Y', strtotime($poll['end_date'])); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="event-footer" style="border-top: none; padding-top: 0;">
                                <a href="vote-poll.php?id=<?= $poll['id']; ?>" class="btn btn-small" style="width: 100%;">
                                    <?= $hasVoted ? 'View Results' : 'Vote Now'; ?>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state" style="margin-bottom: 3rem;">
                <h3>No Active Polls</h3>
                <p>There are no active polls at the moment.</p>
            </div>
        <?php endif; ?>

        <?php if (count($closedPolls) > 0): ?>
            <h2 style="margin: 3rem 0 1.5rem; font-size: 1.5rem;">📁 Closed Polls</h2>
            <div class="grid">
                <?php foreach ($closedPolls as $poll): ?>
                    <div class="event-card" style="opacity: 0.7;">
                        <div class="event-info" style="padding: 1.5rem;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                                <span style="background: rgba(255,255,255,0.2); padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.8rem; font-weight: 700;">
                                    🔒 Closed
                                </span>
                                <span style="font-size: 0.85rem; opacity: 0.7;">
                                    <?= $poll['total_votes']; ?> votes
                                </span>
                            </div>
                            
                            <h3 class="event-title"><?= htmlspecialchars($poll['question']); ?></h3>
                            
                            <div class="event-footer" style="border-top: none; padding-top: 0;">
                                <a href="vote-poll.php?id=<?= $poll['id']; ?>" class="btn btn-small" style="width: 100%; background: rgba(255,255,255,0.2);">
                                    View Results
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
