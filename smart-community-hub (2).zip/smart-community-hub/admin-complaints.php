<?php
require 'config.php';
requireAdmin();  // Make sure only admin can see this page

$result = $conn->query("SELECT c.*, u.username FROM complaints c JOIN users u ON c.user_id = u.id ORDER BY c.created_at DESC");
$complaints = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Complaints</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<nav>
    <div class="nav-container">
        <div class="logo">🚀 SmartHub</div>
        <ul>
            <li><a href="admin-complaints.php" class="active">Complaints</a></li>
            <li style="margin-left:auto;"><a href="logout.php" class="btn btn-small">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="container">

    <h1 style="margin-bottom:2rem;">All Complaints</h1>

    <?php foreach ($complaints as $c): ?>

        <div class="complaint-card">

            <h3 class="complaint-title"><?= htmlspecialchars($c['title']); ?></h3>

            <p><strong>User:</strong> <?= htmlspecialchars($c['username']); ?></p>
            <p><strong>Category:</strong> <?= htmlspecialchars($c['category']); ?></p>
            <p><?= nl2br(htmlspecialchars($c['description'])); ?></p>

            <form method="POST" action="update-complaint-status.php" style="margin-top:1rem;">
                <input type="hidden" name="id" value="<?= $c['id']; ?>">

                <select name="status" class="status-dropdown">
                    <option value="Pending" <?= $c['status']=='Pending'?'selected':''; ?>>Pending</option>
                    <option value="Resolved" <?= $c['status']=='Resolved'?'selected':''; ?>>Resolved</option>
                    <option value="Rejected" <?= $c['status']=='Rejected'?'selected':''; ?>>Rejected</option>
                </select>

                <button class="btn btn-small" type="submit">Update</button>
            </form>

            <p class="date"><?= $c['created_at']; ?></p>

        </div>

    <?php endforeach; ?>

</div>

<style>
.status-dropdown {
    padding: 8px;
    border-radius: 10px;
    margin-right: 10px;
}
</style>

</body>
</html>
