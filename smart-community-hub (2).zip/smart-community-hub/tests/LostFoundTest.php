<?php
/**
 * Unit Tests for Lost & Found
 * Tests item validation, status checks, and filtering
 */

require_once __DIR__ . '/TestFramework.php';
require_once __DIR__ . '/TestHelpers.php';

TestFramework::setTestClass('LostFoundTest');

// ============================================
// Item Validation Tests
// ============================================

TestFramework::test('Valid lost item data passes validation', function() {
    $validItem = [
        'type' => 'lost',
        'title' => 'Golden Watch - Tissot',
        'category' => 'Jewelry',
        'description' => 'Lost my golden watch near the park',
        'location' => 'Community Park, Block A',
        'date_occurred' => date('Y-m-d')
    ];
    
    $errors = LostFoundHelper::validateItem($validItem);
    Assert::assertEmpty($errors, 'Valid lost item should have no errors');
});

TestFramework::test('Valid found item data passes validation', function() {
    $validItem = [
        'type' => 'found',
        'title' => 'Car Keys with BMW Keychain',
        'category' => 'Keys',
        'description' => 'Found car keys in the parking lot',
        'location' => 'Parking Lot B',
        'date_occurred' => date('Y-m-d')
    ];
    
    $errors = LostFoundHelper::validateItem($validItem);
    Assert::assertEmpty($errors, 'Valid found item should have no errors');
});

TestFramework::test('Invalid type fails validation', function() {
    $item = [
        'type' => 'invalid',
        'title' => 'Test Item',
        'category' => 'Keys',
        'description' => 'Description',
        'location' => 'Location',
        'date_occurred' => date('Y-m-d')
    ];
    
    $errors = LostFoundHelper::validateItem($item);
    Assert::assertContains('Type must be either "lost" or "found"', $errors);
});

TestFramework::test('Missing type fails validation', function() {
    $item = [
        'type' => '',
        'title' => 'Test Item',
        'category' => 'Keys',
        'description' => 'Description',
        'location' => 'Location',
        'date_occurred' => date('Y-m-d')
    ];
    
    $errors = LostFoundHelper::validateItem($item);
    Assert::assertContains('Type must be either "lost" or "found"', $errors);
});

TestFramework::test('Missing title fails validation', function() {
    $item = [
        'type' => 'lost',
        'title' => '',
        'category' => 'Keys',
        'description' => 'Description',
        'location' => 'Location',
        'date_occurred' => date('Y-m-d')
    ];
    
    $errors = LostFoundHelper::validateItem($item);
    Assert::assertContains('Title is required', $errors);
});

TestFramework::test('Invalid category fails validation', function() {
    $item = [
        'type' => 'lost',
        'title' => 'Test Item',
        'category' => 'InvalidCategory',
        'description' => 'Description',
        'location' => 'Location',
        'date_occurred' => date('Y-m-d')
    ];
    
    $errors = LostFoundHelper::validateItem($item);
    Assert::assertContains('Valid category is required', $errors);
});

TestFramework::test('Missing description fails validation', function() {
    $item = [
        'type' => 'lost',
        'title' => 'Test Item',
        'category' => 'Keys',
        'description' => '',
        'location' => 'Location',
        'date_occurred' => date('Y-m-d')
    ];
    
    $errors = LostFoundHelper::validateItem($item);
    Assert::assertContains('Description is required', $errors);
});

TestFramework::test('Missing location fails validation', function() {
    $item = [
        'type' => 'lost',
        'title' => 'Test Item',
        'category' => 'Keys',
        'description' => 'Description',
        'location' => '',
        'date_occurred' => date('Y-m-d')
    ];
    
    $errors = LostFoundHelper::validateItem($item);
    Assert::assertContains('Location is required', $errors);
});

TestFramework::test('Missing date fails validation', function() {
    $item = [
        'type' => 'lost',
        'title' => 'Test Item',
        'category' => 'Keys',
        'description' => 'Description',
        'location' => 'Location',
        'date_occurred' => ''
    ];
    
    $errors = LostFoundHelper::validateItem($item);
    Assert::assertContains('Date is required', $errors);
});

TestFramework::test('All valid categories are accepted', function() {
    $categories = ['Electronics', 'Jewelry', 'Keys', 'Wallet', 'Documents', 'Clothing', 'Pets', 'Other'];
    
    foreach ($categories as $category) {
        $item = [
            'type' => 'lost',
            'title' => 'Test',
            'category' => $category,
            'description' => 'Description',
            'location' => 'Location',
            'date_occurred' => date('Y-m-d')
        ];
        
        $errors = LostFoundHelper::validateItem($item);
        Assert::assertEmpty($errors, "Category '$category' should be valid");
    }
});

// ============================================
// Status Tests
// ============================================

TestFramework::test('isOpen returns true for open status', function() {
    Assert::assertTrue(LostFoundHelper::isOpen('open'));
});

TestFramework::test('isOpen returns false for resolved status', function() {
    Assert::assertFalse(LostFoundHelper::isOpen('resolved'));
});

// ============================================
// Filter By Type Tests
// ============================================

TestFramework::test('Filter by type lost works correctly', function() {
    $items = [
        ['id' => 1, 'type' => 'lost', 'title' => 'Lost Watch'],
        ['id' => 2, 'type' => 'found', 'title' => 'Found Keys'],
        ['id' => 3, 'type' => 'lost', 'title' => 'Lost Wallet']
    ];
    
    $filtered = LostFoundHelper::filterByType($items, 'lost');
    Assert::assertCount(2, $filtered);
});

TestFramework::test('Filter by type found works correctly', function() {
    $items = [
        ['id' => 1, 'type' => 'lost', 'title' => 'Lost Watch'],
        ['id' => 2, 'type' => 'found', 'title' => 'Found Keys'],
        ['id' => 3, 'type' => 'lost', 'title' => 'Lost Wallet']
    ];
    
    $filtered = LostFoundHelper::filterByType($items, 'found');
    Assert::assertCount(1, $filtered);
});

TestFramework::test('Empty type filter returns all items', function() {
    $items = [
        ['id' => 1, 'type' => 'lost', 'title' => 'Lost Watch'],
        ['id' => 2, 'type' => 'found', 'title' => 'Found Keys']
    ];
    
    $filtered = LostFoundHelper::filterByType($items, '');
    Assert::assertCount(2, $filtered);
});

// ============================================
// Constants Tests
// ============================================

TestFramework::test('All lost/found types are defined', function() {
    $expectedTypes = ['lost', 'found'];
    Assert::assertEquals($expectedTypes, LostFoundHelper::TYPES);
});

TestFramework::test('All lost/found categories are defined', function() {
    $expectedCategories = ['Electronics', 'Jewelry', 'Keys', 'Wallet', 'Documents', 'Clothing', 'Pets', 'Other'];
    Assert::assertEquals($expectedCategories, LostFoundHelper::CATEGORIES);
});

TestFramework::test('All lost/found statuses are defined', function() {
    $expectedStatuses = ['open', 'resolved'];
    Assert::assertEquals($expectedStatuses, LostFoundHelper::STATUSES);
});

// ============================================
// Multiple Validation Errors Test
// ============================================

TestFramework::test('Multiple validation errors are all returned', function() {
    $item = [
        'type' => 'invalid',
        'title' => '',
        'category' => 'Invalid',
        'description' => '',
        'location' => '',
        'date_occurred' => ''
    ];
    
    $errors = LostFoundHelper::validateItem($item);
    Assert::assertGreaterThan(4, count($errors));
});