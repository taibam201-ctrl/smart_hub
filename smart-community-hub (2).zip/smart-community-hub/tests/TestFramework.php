<?php
/**
 * Simple Test Framework for Smart Community Hub
 * Since PHPUnit cannot be installed due to network restrictions,
 * this provides a lightweight alternative for unit testing.
 */

class TestFramework {
    private static $tests = [];
    private static $passed = 0;
    private static $failed = 0;
    private static $errors = [];
    private static $currentTestClass = '';

    /**
     * Register a test
     */
    public static function test(string $name, callable $callback): void {
        self::$tests[] = [
            'name' => $name,
            'callback' => $callback,
            'class' => self::$currentTestClass
        ];
    }

    /**
     * Set current test class name
     */
    public static function setTestClass(string $className): void {
        self::$currentTestClass = $className;
    }

    /**
     * Run all registered tests
     */
    public static function run(): void {
        echo "\n" . str_repeat("=", 70) . "\n";
        echo "  SMART COMMUNITY HUB - UNIT TEST SUITE\n";
        echo str_repeat("=", 70) . "\n\n";

        $currentClass = '';
        
        foreach (self::$tests as $test) {
            if ($test['class'] !== $currentClass) {
                $currentClass = $test['class'];
                echo "\n📁 " . $currentClass . "\n";
                echo str_repeat("-", 50) . "\n";
            }

            try {
                $test['callback']();
                self::$passed++;
                echo "  ✅ {$test['name']}\n";
            } catch (AssertionError $e) {
                self::$failed++;
                self::$errors[] = [
                    'test' => $test['name'],
                    'class' => $test['class'],
                    'message' => $e->getMessage()
                ];
                echo "  ❌ {$test['name']}\n";
                echo "     └─ {$e->getMessage()}\n";
            } catch (Exception $e) {
                self::$failed++;
                self::$errors[] = [
                    'test' => $test['name'],
                    'class' => $test['class'],
                    'message' => 'Exception: ' . $e->getMessage()
                ];
                echo "  ❌ {$test['name']}\n";
                echo "     └─ Exception: {$e->getMessage()}\n";
            }
        }

        self::printSummary();
    }

    /**
     * Print test summary
     */
    private static function printSummary(): void {
        $total = self::$passed + self::$failed;
        
        echo "\n" . str_repeat("=", 70) . "\n";
        echo "  TEST RESULTS SUMMARY\n";
        echo str_repeat("=", 70) . "\n";
        echo "  Total Tests: {$total}\n";
        echo "  ✅ Passed: " . self::$passed . "\n";
        echo "  ❌ Failed: " . self::$failed . "\n";
        
        if (self::$failed > 0) {
            $percentage = round((self::$passed / $total) * 100, 1);
            echo "  📊 Pass Rate: {$percentage}%\n";
        } else {
            echo "  📊 Pass Rate: 100%\n";
        }
        
        echo str_repeat("=", 70) . "\n\n";

        if (count(self::$errors) > 0) {
            echo "FAILURE DETAILS:\n";
            echo str_repeat("-", 70) . "\n";
            foreach (self::$errors as $error) {
                echo "  [{$error['class']}] {$error['test']}\n";
                echo "    {$error['message']}\n\n";
            }
        }
    }

    /**
     * Reset test state (useful for running multiple test suites)
     */
    public static function reset(): void {
        self::$tests = [];
        self::$passed = 0;
        self::$failed = 0;
        self::$errors = [];
        self::$currentTestClass = '';
    }
}

/**
 * Assertion class for test assertions
 */
class Assert {
    public static function assertTrue($condition, string $message = 'Expected true, got false'): void {
        if ($condition !== true) {
            throw new AssertionError($message);
        }
    }

    public static function assertFalse($condition, string $message = 'Expected false, got true'): void {
        if ($condition !== false) {
            throw new AssertionError($message);
        }
    }

    public static function assertEquals($expected, $actual, string $message = ''): void {
        if ($expected !== $actual) {
            $msg = $message ?: "Expected '" . var_export($expected, true) . "', got '" . var_export($actual, true) . "'";
            throw new AssertionError($msg);
        }
    }

    public static function assertNotEquals($expected, $actual, string $message = ''): void {
        if ($expected === $actual) {
            $msg = $message ?: "Expected values to be different, both are '" . var_export($actual, true) . "'";
            throw new AssertionError($msg);
        }
    }

    public static function assertNull($value, string $message = 'Expected null'): void {
        if ($value !== null) {
            throw new AssertionError($message);
        }
    }

    public static function assertNotNull($value, string $message = 'Expected non-null value'): void {
        if ($value === null) {
            throw new AssertionError($message);
        }
    }

    public static function assertEmpty($value, string $message = 'Expected empty value'): void {
        if (!empty($value)) {
            throw new AssertionError($message);
        }
    }

    public static function assertNotEmpty($value, string $message = 'Expected non-empty value'): void {
        if (empty($value)) {
            throw new AssertionError($message);
        }
    }

    public static function assertContains($needle, $haystack, string $message = ''): void {
        if (is_array($haystack)) {
            if (!in_array($needle, $haystack)) {
                $msg = $message ?: "Array does not contain expected value";
                throw new AssertionError($msg);
            }
        } elseif (is_string($haystack)) {
            if (strpos($haystack, $needle) === false) {
                $msg = $message ?: "String does not contain expected substring";
                throw new AssertionError($msg);
            }
        } else {
            throw new AssertionError("assertContains requires array or string");
        }
    }

    public static function assertNotContains($needle, $haystack, string $message = ''): void {
        if (is_array($haystack)) {
            if (in_array($needle, $haystack)) {
                $msg = $message ?: "Array contains unexpected value";
                throw new AssertionError($msg);
            }
        } elseif (is_string($haystack)) {
            if (strpos($haystack, $needle) !== false) {
                $msg = $message ?: "String contains unexpected substring";
                throw new AssertionError($msg);
            }
        }
    }

    public static function assertCount(int $expected, $array, string $message = ''): void {
        $actual = count($array);
        if ($expected !== $actual) {
            $msg = $message ?: "Expected count {$expected}, got {$actual}";
            throw new AssertionError($msg);
        }
    }

    public static function assertGreaterThan($expected, $actual, string $message = ''): void {
        if ($actual <= $expected) {
            $msg = $message ?: "Expected value greater than {$expected}, got {$actual}";
            throw new AssertionError($msg);
        }
    }

    public static function assertLessThan($expected, $actual, string $message = ''): void {
        if ($actual >= $expected) {
            $msg = $message ?: "Expected value less than {$expected}, got {$actual}";
            throw new AssertionError($msg);
        }
    }

    public static function assertInstanceOf(string $expected, $actual, string $message = ''): void {
        if (!($actual instanceof $expected)) {
            $actualType = is_object($actual) ? get_class($actual) : gettype($actual);
            $msg = $message ?: "Expected instance of {$expected}, got {$actualType}";
            throw new AssertionError($msg);
        }
    }

    public static function assertIsArray($value, string $message = 'Expected array'): void {
        if (!is_array($value)) {
            throw new AssertionError($message);
        }
    }

    public static function assertIsString($value, string $message = 'Expected string'): void {
        if (!is_string($value)) {
            throw new AssertionError($message);
        }
    }

    public static function assertIsInt($value, string $message = 'Expected integer'): void {
        if (!is_int($value)) {
            throw new AssertionError($message);
        }
    }

    public static function assertIsBool($value, string $message = 'Expected boolean'): void {
        if (!is_bool($value)) {
            throw new AssertionError($message);
        }
    }

    public static function assertMatchesRegex(string $pattern, string $string, string $message = ''): void {
        if (!preg_match($pattern, $string)) {
            $msg = $message ?: "String does not match pattern {$pattern}";
            throw new AssertionError($msg);
        }
    }

    public static function assertArrayHasKey($key, array $array, string $message = ''): void {
        if (!array_key_exists($key, $array)) {
            $msg = $message ?: "Array does not have expected key '{$key}'";
            throw new AssertionError($msg);
        }
    }

    public static function assertArrayNotHasKey($key, array $array, string $message = ''): void {
        if (array_key_exists($key, $array)) {
            $msg = $message ?: "Array has unexpected key '{$key}'";
            throw new AssertionError($msg);
        }
    }
}

/**
 * Mock Database Connection for testing
 */
class MockDatabase {
    private $tables = [];
    private $queryLog = [];
    private $lastInsertId = 0;

    public function __construct() {
        $this->initializeTables();
    }

    private function initializeTables(): void {
        $this->tables = [
            'users' => [],
            'events' => [],
            'registrations' => [],
            'announcements' => [],
            'announcement_comments' => [],
            'complaints' => [],
            'marketplace' => [],
            'lost_found' => [],
            'polls' => [],
            'poll_options' => [],
            'poll_votes' => [],
            'documents' => [],
            'community_directory' => [],
            'faqs' => [],
            'user_questions' => []
        ];
    }

    public function insert(string $table, array $data): int {
        $this->lastInsertId++;
        $data['id'] = $this->lastInsertId;
        $data['created_at'] = date('Y-m-d H:i:s');
        $this->tables[$table][] = $data;
        $this->queryLog[] = ['type' => 'INSERT', 'table' => $table, 'data' => $data];
        return $this->lastInsertId;
    }

    public function select(string $table, array $conditions = []): array {
        $this->queryLog[] = ['type' => 'SELECT', 'table' => $table, 'conditions' => $conditions];
        
        if (empty($conditions)) {
            return $this->tables[$table] ?? [];
        }

        return array_filter($this->tables[$table] ?? [], function($row) use ($conditions) {
            foreach ($conditions as $key => $value) {
                if (!isset($row[$key]) || $row[$key] != $value) {
                    return false;
                }
            }
            return true;
        });
    }

    public function update(string $table, array $data, array $conditions): bool {
        $this->queryLog[] = ['type' => 'UPDATE', 'table' => $table, 'data' => $data, 'conditions' => $conditions];
        
        foreach ($this->tables[$table] as &$row) {
            $match = true;
            foreach ($conditions as $key => $value) {
                if (!isset($row[$key]) || $row[$key] != $value) {
                    $match = false;
                    break;
                }
            }
            if ($match) {
                $row = array_merge($row, $data);
            }
        }
        return true;
    }

    public function delete(string $table, array $conditions): bool {
        $this->queryLog[] = ['type' => 'DELETE', 'table' => $table, 'conditions' => $conditions];
        
        $this->tables[$table] = array_filter($this->tables[$table], function($row) use ($conditions) {
            foreach ($conditions as $key => $value) {
                if (!isset($row[$key]) || $row[$key] != $value) {
                    return true;
                }
            }
            return false;
        });
        return true;
    }

    public function getLastInsertId(): int {
        return $this->lastInsertId;
    }

    public function getQueryLog(): array {
        return $this->queryLog;
    }

    public function reset(): void {
        $this->initializeTables();
        $this->queryLog = [];
        $this->lastInsertId = 0;
    }

    public function real_escape_string(string $string): string {
        return addslashes($string);
    }
}

/**
 * Mock Session for testing
 */
class MockSession {
    private static $data = [];

    public static function set(string $key, $value): void {
        self::$data[$key] = $value;
    }

    public static function get(string $key, $default = null) {
        return self::$data[$key] ?? $default;
    }

    public static function has(string $key): bool {
        return isset(self::$data[$key]);
    }

    public static function remove(string $key): void {
        unset(self::$data[$key]);
    }

    public static function clear(): void {
        self::$data = [];
    }

    public static function all(): array {
        return self::$data;
    }
}