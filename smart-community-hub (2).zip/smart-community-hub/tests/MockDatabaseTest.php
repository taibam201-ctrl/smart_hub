<?php
/**
 * Unit Tests for Mock Database
 * Tests database CRUD operations and query logging
 */

require_once __DIR__ . '/TestFramework.php';
require_once __DIR__ . '/TestHelpers.php';

TestFramework::setTestClass('MockDatabaseTest');

// ============================================
// Insert Tests
// ============================================

TestFramework::test('Insert returns auto-increment ID', function() {
    $db = new MockDatabase();
    
    $id1 = $db->insert('users', ['username' => 'john', 'email' => 'john@test.com']);
    $id2 = $db->insert('users', ['username' => 'jane', 'email' => 'jane@test.com']);
    
    Assert::assertEquals(1, $id1);
    Assert::assertEquals(2, $id2);
});

TestFramework::test('Insert adds created_at timestamp', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john']);
    $users = $db->select('users');
    
    Assert::assertArrayHasKey('created_at', $users[0]);
});

TestFramework::test('Insert logs query', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john']);
    $log = $db->getQueryLog();
    
    Assert::assertCount(1, $log);
    Assert::assertEquals('INSERT', $log[0]['type']);
    Assert::assertEquals('users', $log[0]['table']);
});

// ============================================
// Select Tests
// ============================================

TestFramework::test('Select all returns all records', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john']);
    $db->insert('users', ['username' => 'jane']);
    $db->insert('users', ['username' => 'bob']);
    
    $users = $db->select('users');
    Assert::assertCount(3, $users);
});

TestFramework::test('Select with conditions filters correctly', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john', 'is_admin' => true]);
    $db->insert('users', ['username' => 'jane', 'is_admin' => false]);
    $db->insert('users', ['username' => 'bob', 'is_admin' => true]);
    
    $admins = $db->select('users', ['is_admin' => true]);
    Assert::assertCount(2, $admins);
});

TestFramework::test('Select from empty table returns empty array', function() {
    $db = new MockDatabase();
    
    $users = $db->select('users');
    Assert::assertEmpty($users);
});

TestFramework::test('Select with non-matching conditions returns empty', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john']);
    
    $users = $db->select('users', ['username' => 'nonexistent']);
    Assert::assertEmpty($users);
});

// ============================================
// Update Tests
// ============================================

TestFramework::test('Update modifies matching records', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john', 'email' => 'old@test.com']);
    $db->update('users', ['email' => 'new@test.com'], ['username' => 'john']);
    
    $users = $db->select('users', ['username' => 'john']);
    Assert::assertEquals('new@test.com', array_values($users)[0]['email']);
});

TestFramework::test('Update only modifies matching records', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john', 'email' => 'john@test.com']);
    $db->insert('users', ['username' => 'jane', 'email' => 'jane@test.com']);
    
    $db->update('users', ['email' => 'updated@test.com'], ['username' => 'john']);
    
    $john = $db->select('users', ['username' => 'john']);
    $jane = $db->select('users', ['username' => 'jane']);
    
    Assert::assertEquals('updated@test.com', array_values($john)[0]['email']);
    Assert::assertEquals('jane@test.com', array_values($jane)[0]['email']);
});

// ============================================
// Delete Tests
// ============================================

TestFramework::test('Delete removes matching records', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john']);
    $db->insert('users', ['username' => 'jane']);
    
    $db->delete('users', ['username' => 'john']);
    
    $users = $db->select('users');
    Assert::assertCount(1, $users);
    Assert::assertEquals('jane', array_values($users)[0]['username']);
});

TestFramework::test('Delete only removes matching records', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john', 'role' => 'admin']);
    $db->insert('users', ['username' => 'jane', 'role' => 'user']);
    $db->insert('users', ['username' => 'bob', 'role' => 'admin']);
    
    $db->delete('users', ['role' => 'admin']);
    
    $users = $db->select('users');
    Assert::assertCount(1, $users);
});

// ============================================
// Reset Tests
// ============================================

TestFramework::test('Reset clears all data', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john']);
    $db->insert('events', ['title' => 'Event 1']);
    
    $db->reset();
    
    Assert::assertEmpty($db->select('users'));
    Assert::assertEmpty($db->select('events'));
    // Note: Query log will have SELECT queries from assertions above
    // Just verify no INSERT queries remain by checking data is empty
});

TestFramework::test('Reset resets auto-increment', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john']);
    $db->insert('users', ['username' => 'jane']);
    
    $db->reset();
    
    $id = $db->insert('users', ['username' => 'new']);
    Assert::assertEquals(1, $id);
});

// ============================================
// Last Insert ID Tests
// ============================================

TestFramework::test('getLastInsertId returns correct ID', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john']);
    Assert::assertEquals(1, $db->getLastInsertId());
    
    $db->insert('users', ['username' => 'jane']);
    Assert::assertEquals(2, $db->getLastInsertId());
});

// ============================================
// Real Escape String Tests
// ============================================

TestFramework::test('real_escape_string escapes quotes', function() {
    $db = new MockDatabase();
    
    $escaped = $db->real_escape_string("O'Brien");
    Assert::assertContains("\\", $escaped);
});

TestFramework::test('real_escape_string escapes double quotes', function() {
    $db = new MockDatabase();
    
    $escaped = $db->real_escape_string('Say "Hello"');
    Assert::assertContains("\\", $escaped);
});

// ============================================
// Query Log Tests
// ============================================

TestFramework::test('Query log records all operations', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john']);
    $db->select('users');
    $db->update('users', ['email' => 'test@test.com'], ['id' => 1]);
    $db->delete('users', ['id' => 1]);
    
    $log = $db->getQueryLog();
    
    Assert::assertCount(4, $log);
    Assert::assertEquals('INSERT', $log[0]['type']);
    Assert::assertEquals('SELECT', $log[1]['type']);
    Assert::assertEquals('UPDATE', $log[2]['type']);
    Assert::assertEquals('DELETE', $log[3]['type']);
});

// ============================================
// Multi-table Tests
// ============================================

TestFramework::test('Operations on different tables are independent', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john']);
    $db->insert('events', ['title' => 'BBQ Night']);
    $db->insert('polls', ['question' => 'What should we do?']);
    
    Assert::assertCount(1, $db->select('users'));
    Assert::assertCount(1, $db->select('events'));
    Assert::assertCount(1, $db->select('polls'));
});

TestFramework::test('Delete from one table does not affect others', function() {
    $db = new MockDatabase();
    
    $db->insert('users', ['username' => 'john']);
    $db->insert('events', ['title' => 'BBQ Night']);
    
    $db->delete('users', ['username' => 'john']);
    
    Assert::assertEmpty($db->select('users'));
    Assert::assertCount(1, $db->select('events'));
});