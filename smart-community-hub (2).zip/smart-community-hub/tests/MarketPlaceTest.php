<?php
/**
 * Unit Tests for Marketplace
 * Tests listing validation, filtering, sorting, and price formatting
 */

require_once __DIR__ . '/TestFramework.php';
require_once __DIR__ . '/TestHelpers.php';

TestFramework::setTestClass('MarketplaceTest');

// ============================================
// Listing Validation Tests
// ============================================

TestFramework::test('Valid listing data passes validation', function() {
    $validListing = [
        'title' => 'Gaming Laptop',
        'category' => 'Electronics',
        'description' => 'Excellent gaming laptop, Intel i7',
        'price' => 85000,
        'condition' => 'like_new'
    ];
    
    $errors = MarketplaceHelper::validateListing($validListing);
    Assert::assertEmpty($errors, 'Valid listing should have no errors');
});

TestFramework::test('Missing title fails validation', function() {
    $listing = [
        'title' => '',
        'category' => 'Electronics',
        'description' => 'Some description',
        'price' => 100
    ];
    
    $errors = MarketplaceHelper::validateListing($listing);
    Assert::assertNotEmpty($errors);
    Assert::assertContains('Title is required', $errors);
});

TestFramework::test('Missing category fails validation', function() {
    $listing = [
        'title' => 'Test Item',
        'category' => '',
        'description' => 'Some description',
        'price' => 100
    ];
    
    $errors = MarketplaceHelper::validateListing($listing);
    Assert::assertNotEmpty($errors);
    Assert::assertContains('Valid category is required', $errors);
});

TestFramework::test('Invalid category fails validation', function() {
    $listing = [
        'title' => 'Test Item',
        'category' => 'InvalidCategory',
        'description' => 'Some description',
        'price' => 100
    ];
    
    $errors = MarketplaceHelper::validateListing($listing);
    Assert::assertContains('Valid category is required', $errors);
});

TestFramework::test('Missing description fails validation', function() {
    $listing = [
        'title' => 'Test Item',
        'category' => 'Electronics',
        'description' => '',
        'price' => 100
    ];
    
    $errors = MarketplaceHelper::validateListing($listing);
    Assert::assertContains('Description is required', $errors);
});

TestFramework::test('Negative price fails validation', function() {
    $listing = [
        'title' => 'Test Item',
        'category' => 'Electronics',
        'description' => 'Some description',
        'price' => -100
    ];
    
    $errors = MarketplaceHelper::validateListing($listing);
    Assert::assertContains('Valid price is required (0 or positive number)', $errors);
});

TestFramework::test('Zero price is valid (free items)', function() {
    $listing = [
        'title' => 'Free Item',
        'category' => 'Other',
        'description' => 'Giving away for free',
        'price' => 0
    ];
    
    $errors = MarketplaceHelper::validateListing($listing);
    Assert::assertEmpty($errors);
});

TestFramework::test('Invalid condition fails validation', function() {
    $listing = [
        'title' => 'Test Item',
        'category' => 'Electronics',
        'description' => 'Some description',
        'price' => 100,
        'condition' => 'invalid_condition'
    ];
    
    $errors = MarketplaceHelper::validateListing($listing);
    Assert::assertContains('Invalid condition specified', $errors);
});

TestFramework::test('All valid conditions are accepted', function() {
    $conditions = ['new', 'like_new', 'good', 'fair', 'poor'];
    
    foreach ($conditions as $condition) {
        $listing = [
            'title' => 'Test Item',
            'category' => 'Electronics',
            'description' => 'Some description',
            'price' => 100,
            'condition' => $condition
        ];
        
        $errors = MarketplaceHelper::validateListing($listing);
        Assert::assertEmpty($errors, "Condition '$condition' should be valid");
    }
});

// ============================================
// Price Formatting Tests
// ============================================

TestFramework::test('Non-zero price is formatted with currency', function() {
    Assert::assertEquals('Rs. 85,000', MarketplaceHelper::formatPrice(85000));
    Assert::assertEquals('Rs. 1,000', MarketplaceHelper::formatPrice(1000));
    Assert::assertEquals('Rs. 500', MarketplaceHelper::formatPrice(500));
});

TestFramework::test('Zero price shows Free', function() {
    Assert::assertEquals('Free', MarketplaceHelper::formatPrice(0));
});

TestFramework::test('Decimal prices are formatted correctly', function() {
    // PHP's number_format rounds 1500.50 to 1,501
    Assert::assertEquals('Rs. 1,501', MarketplaceHelper::formatPrice(1500.50));
    Assert::assertEquals('Rs. 1,000', MarketplaceHelper::formatPrice(1000.00));
});

// ============================================
// Status Check Tests
// ============================================

TestFramework::test('Available status check works correctly', function() {
    Assert::assertTrue(MarketplaceHelper::isAvailable('available'));
    Assert::assertFalse(MarketplaceHelper::isAvailable('sold'));
    Assert::assertFalse(MarketplaceHelper::isAvailable('removed'));
});

// ============================================
// Search Filtering Tests
// ============================================

TestFramework::test('Filter by search term works on title', function() {
    $items = [
        ['title' => 'Gaming Laptop', 'description' => 'Great for gaming'],
        ['title' => 'Office Chair', 'description' => 'Ergonomic chair'],
        ['title' => 'Gaming Mouse', 'description' => 'High DPI mouse']
    ];
    
    $filtered = MarketplaceHelper::filterBySearch($items, 'Gaming');
    Assert::assertCount(2, $filtered);
});

TestFramework::test('Filter by search term works on description', function() {
    $items = [
        ['title' => 'Laptop', 'description' => 'Great for gaming'],
        ['title' => 'Chair', 'description' => 'Ergonomic office chair'],
        ['title' => 'Mouse', 'description' => 'High DPI gaming mouse']
    ];
    
    $filtered = MarketplaceHelper::filterBySearch($items, 'gaming');
    Assert::assertCount(2, $filtered);
});

TestFramework::test('Empty search returns all items', function() {
    $items = [
        ['title' => 'Item 1', 'description' => 'Desc 1'],
        ['title' => 'Item 2', 'description' => 'Desc 2']
    ];
    
    $filtered = MarketplaceHelper::filterBySearch($items, '');
    Assert::assertCount(2, $filtered);
});

TestFramework::test('Search is case-insensitive', function() {
    $items = [
        ['title' => 'LAPTOP', 'description' => 'Gaming laptop'],
        ['title' => 'chair', 'description' => 'Office Chair']
    ];
    
    $filtered = MarketplaceHelper::filterBySearch($items, 'laptop');
    Assert::assertCount(1, $filtered);
    
    $filtered2 = MarketplaceHelper::filterBySearch($items, 'CHAIR');
    Assert::assertCount(1, $filtered2);
});

// ============================================
// Category Filtering Tests
// ============================================

TestFramework::test('Filter by category works correctly', function() {
    $items = [
        ['title' => 'Laptop', 'category' => 'Electronics'],
        ['title' => 'Chair', 'category' => 'Furniture'],
        ['title' => 'Phone', 'category' => 'Electronics']
    ];
    
    $filtered = MarketplaceHelper::filterByCategory($items, 'Electronics');
    Assert::assertCount(2, $filtered);
});

TestFramework::test('Empty category returns all items', function() {
    $items = [
        ['title' => 'Item 1', 'category' => 'Electronics'],
        ['title' => 'Item 2', 'category' => 'Furniture']
    ];
    
    $filtered = MarketplaceHelper::filterByCategory($items, '');
    Assert::assertCount(2, $filtered);
});

// ============================================
// Sorting Tests
// ============================================

TestFramework::test('Sort by price low to high works', function() {
    $items = [
        ['title' => 'Item 1', 'price' => 500, 'created_at' => '2024-01-01'],
        ['title' => 'Item 2', 'price' => 100, 'created_at' => '2024-01-02'],
        ['title' => 'Item 3', 'price' => 300, 'created_at' => '2024-01-03']
    ];
    
    $sorted = MarketplaceHelper::sortItems($items, 'price_low');
    Assert::assertEquals(100, $sorted[0]['price']);
    Assert::assertEquals(300, $sorted[1]['price']);
    Assert::assertEquals(500, $sorted[2]['price']);
});

TestFramework::test('Sort by price high to low works', function() {
    $items = [
        ['title' => 'Item 1', 'price' => 500, 'created_at' => '2024-01-01'],
        ['title' => 'Item 2', 'price' => 100, 'created_at' => '2024-01-02'],
        ['title' => 'Item 3', 'price' => 300, 'created_at' => '2024-01-03']
    ];
    
    $sorted = MarketplaceHelper::sortItems($items, 'price_high');
    Assert::assertEquals(500, $sorted[0]['price']);
    Assert::assertEquals(300, $sorted[1]['price']);
    Assert::assertEquals(100, $sorted[2]['price']);
});

TestFramework::test('Sort by newest first works', function() {
    $items = [
        ['title' => 'Old Item', 'price' => 100, 'created_at' => '2024-01-01 10:00:00'],
        ['title' => 'New Item', 'price' => 100, 'created_at' => '2024-12-15 10:00:00'],
        ['title' => 'Middle Item', 'price' => 100, 'created_at' => '2024-06-01 10:00:00']
    ];
    
    $sorted = MarketplaceHelper::sortItems($items, 'newest');
    Assert::assertEquals('New Item', $sorted[0]['title']);
    Assert::assertEquals('Middle Item', $sorted[1]['title']);
    Assert::assertEquals('Old Item', $sorted[2]['title']);
});

// ============================================
// Constants Tests
// ============================================

TestFramework::test('All marketplace categories are defined', function() {
    $expectedCategories = ['Electronics', 'Furniture', 'Clothing', 'Books', 'Sports', 'Home', 'Services', 'Other'];
    Assert::assertEquals($expectedCategories, MarketplaceHelper::CATEGORIES);
});

TestFramework::test('All marketplace conditions are defined', function() {
    $expectedConditions = ['new', 'like_new', 'good', 'fair', 'poor'];
    Assert::assertEquals($expectedConditions, MarketplaceHelper::CONDITIONS);
});

TestFramework::test('All marketplace statuses are defined', function() {
    $expectedStatuses = ['available', 'sold', 'removed'];
    Assert::assertEquals($expectedStatuses, MarketplaceHelper::STATUSES);
});