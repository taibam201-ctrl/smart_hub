<?php
/**
 * Unit Tests for Events
 * Tests event validation, capacity checks, and date handling
 */

require_once __DIR__ . '/TestFramework.php';
require_once __DIR__ . '/TestHelpers.php';

TestFramework::setTestClass('EventsTest');

// ============================================
// Event Validation Tests
// ============================================

TestFramework::test('Valid event data passes validation', function() {
    $validEvent = [
        'title' => 'Community BBQ Night',
        'category' => 'Social',
        'date' => date('Y-m-d', strtotime('+7 days')),
        'time' => '18:00',
        'location' => 'Community Garden',
        'capacity' => 50
    ];
    
    $errors = EventHelper::validateEvent($validEvent);
    Assert::assertEmpty($errors, 'Valid event should have no errors');
});

TestFramework::test('Missing title fails validation', function() {
    $event = [
        'title' => '',
        'category' => 'Social',
        'date' => date('Y-m-d'),
        'time' => '18:00',
        'location' => 'Some Place',
        'capacity' => 50
    ];
    
    $errors = EventHelper::validateEvent($event);
    Assert::assertContains('Title is required', $errors);
});

TestFramework::test('Missing category fails validation', function() {
    $event = [
        'title' => 'Test Event',
        'category' => '',
        'date' => date('Y-m-d'),
        'time' => '18:00',
        'location' => 'Some Place',
        'capacity' => 50
    ];
    
    $errors = EventHelper::validateEvent($event);
    Assert::assertContains('Valid category is required', $errors);
});

TestFramework::test('Invalid category fails validation', function() {
    $event = [
        'title' => 'Test Event',
        'category' => 'InvalidCategory',
        'date' => date('Y-m-d'),
        'time' => '18:00',
        'location' => 'Some Place',
        'capacity' => 50
    ];
    
    $errors = EventHelper::validateEvent($event);
    Assert::assertContains('Valid category is required', $errors);
});

TestFramework::test('Missing date fails validation', function() {
    $event = [
        'title' => 'Test Event',
        'category' => 'Social',
        'date' => '',
        'time' => '18:00',
        'location' => 'Some Place',
        'capacity' => 50
    ];
    
    $errors = EventHelper::validateEvent($event);
    Assert::assertContains('Date is required', $errors);
});

TestFramework::test('Missing time fails validation', function() {
    $event = [
        'title' => 'Test Event',
        'category' => 'Social',
        'date' => date('Y-m-d'),
        'time' => '',
        'location' => 'Some Place',
        'capacity' => 50
    ];
    
    $errors = EventHelper::validateEvent($event);
    Assert::assertContains('Time is required', $errors);
});

TestFramework::test('Missing location fails validation', function() {
    $event = [
        'title' => 'Test Event',
        'category' => 'Social',
        'date' => date('Y-m-d'),
        'time' => '18:00',
        'location' => '',
        'capacity' => 50
    ];
    
    $errors = EventHelper::validateEvent($event);
    Assert::assertContains('Location is required', $errors);
});

TestFramework::test('Invalid capacity fails validation', function() {
    $event = [
        'title' => 'Test Event',
        'category' => 'Social',
        'date' => date('Y-m-d'),
        'time' => '18:00',
        'location' => 'Some Place',
        'capacity' => 0
    ];
    
    $errors = EventHelper::validateEvent($event);
    Assert::assertContains('Valid capacity is required', $errors);
});

TestFramework::test('Negative capacity fails validation', function() {
    $event = [
        'title' => 'Test Event',
        'category' => 'Social',
        'date' => date('Y-m-d'),
        'time' => '18:00',
        'location' => 'Some Place',
        'capacity' => -10
    ];
    
    $errors = EventHelper::validateEvent($event);
    Assert::assertContains('Valid capacity is required', $errors);
});

TestFramework::test('All valid categories are accepted', function() {
    $categories = ['Sports', 'Social', 'Cultural', 'Educational', 'Meeting', 'Other'];
    
    foreach ($categories as $category) {
        $event = [
            'title' => 'Test',
            'category' => $category,
            'date' => date('Y-m-d'),
            'time' => '18:00',
            'location' => 'Place',
            'capacity' => 50
        ];
        
        $errors = EventHelper::validateEvent($event);
        Assert::assertEmpty($errors, "Category '$category' should be valid");
    }
});

// ============================================
// Capacity Tests
// ============================================

TestFramework::test('Event is full when registered equals capacity', function() {
    Assert::assertTrue(EventHelper::isFull(50, 50));
});

TestFramework::test('Event is full when registered exceeds capacity', function() {
    Assert::assertTrue(EventHelper::isFull(50, 55));
});

TestFramework::test('Event is not full when spots available', function() {
    Assert::assertFalse(EventHelper::isFull(50, 30));
});

TestFramework::test('Event with no registrations is not full', function() {
    Assert::assertFalse(EventHelper::isFull(50, 0));
});

TestFramework::test('Get available spots calculates correctly', function() {
    Assert::assertEquals(20, EventHelper::getAvailableSpots(50, 30));
    Assert::assertEquals(0, EventHelper::getAvailableSpots(50, 50));
    Assert::assertEquals(50, EventHelper::getAvailableSpots(50, 0));
});

TestFramework::test('Get available spots never returns negative', function() {
    Assert::assertEquals(0, EventHelper::getAvailableSpots(50, 55));
    Assert::assertEquals(0, EventHelper::getAvailableSpots(50, 100));
});

// ============================================
// Date Tests
// ============================================

TestFramework::test('Future date is upcoming', function() {
    $futureDate = date('Y-m-d', strtotime('+7 days'));
    Assert::assertTrue(EventHelper::isUpcoming($futureDate));
});

TestFramework::test('Today is upcoming', function() {
    $today = date('Y-m-d');
    Assert::assertTrue(EventHelper::isUpcoming($today));
});

TestFramework::test('Past date is not upcoming', function() {
    $pastDate = date('Y-m-d', strtotime('-7 days'));
    Assert::assertFalse(EventHelper::isUpcoming($pastDate));
});

TestFramework::test('Past date is past', function() {
    $pastDate = date('Y-m-d', strtotime('-1 day'));
    Assert::assertTrue(EventHelper::isPast($pastDate));
});

TestFramework::test('Today is not past', function() {
    $today = date('Y-m-d');
    Assert::assertFalse(EventHelper::isPast($today));
});

TestFramework::test('Future date is not past', function() {
    $futureDate = date('Y-m-d', strtotime('+7 days'));
    Assert::assertFalse(EventHelper::isPast($futureDate));
});

// ============================================
// Constants Tests
// ============================================

TestFramework::test('All event categories are defined', function() {
    $expectedCategories = ['Sports', 'Social', 'Cultural', 'Educational', 'Meeting', 'Other'];
    Assert::assertEquals($expectedCategories, EventHelper::CATEGORIES);
});

// ============================================
// Multiple Validation Errors Test
// ============================================

TestFramework::test('Multiple validation errors are all returned', function() {
    $event = [
        'title' => '',
        'category' => 'Invalid',
        'date' => '',
        'time' => '',
        'location' => '',
        'capacity' => 0
    ];
    
    $errors = EventHelper::validateEvent($event);
    Assert::assertGreaterThan(4, count($errors));
});

// ============================================
// Integration-like Tests
// ============================================

TestFramework::test('Complete event registration scenario', function() {
    // Event with capacity of 50
    $capacity = 50;
    $registered = 0;
    
    // Initial state
    Assert::assertFalse(EventHelper::isFull($capacity, $registered));
    Assert::assertEquals(50, EventHelper::getAvailableSpots($capacity, $registered));
    
    // After some registrations
    $registered = 45;
    Assert::assertFalse(EventHelper::isFull($capacity, $registered));
    Assert::assertEquals(5, EventHelper::getAvailableSpots($capacity, $registered));
    
    // Event becomes full
    $registered = 50;
    Assert::assertTrue(EventHelper::isFull($capacity, $registered));
    Assert::assertEquals(0, EventHelper::getAvailableSpots($capacity, $registered));
});