<?php
/**
 * Test Helpers - Extracted business logic from the application
 * for unit testing without database dependencies
 */

/**
 * User Authentication Helpers
 */
class UserHelper {
    /**
     * Validate email format
     */
    public static function isValidEmail(string $email): bool {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    /**
     * Validate username (minimum 3 characters)
     */
    public static function isValidUsername(string $username): bool {
        return strlen(trim($username)) >= 3;
    }

    /**
     * Validate password (minimum 6 characters)
     */
    public static function isValidPassword(string $password): bool {
        return strlen($password) >= 6;
    }

    /**
     * Check if passwords match
     */
    public static function passwordsMatch(string $password, string $confirmPassword): bool {
        return $password === $confirmPassword;
    }

    /**
     * Validate login input (can be email or username)
     */
    public static function isValidLoginInput(string $input): bool {
        $trimmed = trim($input);
        return !empty($trimmed) && (self::isValidEmail($trimmed) || self::isValidUsername($trimmed));
    }

    /**
     * Check if user is logged in (based on session data)
     */
    public static function isLoggedIn(array $session): bool {
        return isset($session['user_id']) && !empty($session['user_id']);
    }

    /**
     * Check if user is admin
     */
    public static function isAdmin(array $session): bool {
        return isset($session['is_admin']) && $session['is_admin'] == true;
    }

    /**
     * Sanitize user input
     */
    public static function sanitize(string $input): string {
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
}

/**
 * Marketplace Helpers
 */
class MarketplaceHelper {
    const CATEGORIES = [
        'Electronics',
        'Furniture', 
        'Clothing',
        'Books',
        'Sports',
        'Home',
        'Services',
        'Other'
    ];

    const CONDITIONS = ['new', 'like_new', 'good', 'fair', 'poor'];
    const STATUSES = ['available', 'sold', 'removed'];

    /**
     * Validate listing data
     */
    public static function validateListing(array $data): array {
        $errors = [];

        if (empty($data['title'])) {
            $errors[] = 'Title is required';
        }

        if (empty($data['category']) || !in_array($data['category'], self::CATEGORIES)) {
            $errors[] = 'Valid category is required';
        }

        if (empty($data['description'])) {
            $errors[] = 'Description is required';
        }

        if (!isset($data['price']) || !is_numeric($data['price']) || $data['price'] < 0) {
            $errors[] = 'Valid price is required (0 or positive number)';
        }

        if (!empty($data['condition']) && !in_array($data['condition'], self::CONDITIONS)) {
            $errors[] = 'Invalid condition specified';
        }

        return $errors;
    }

    /**
     * Format price for display
     */
    public static function formatPrice(float $price): string {
        return $price > 0 ? 'Rs. ' . number_format($price) : 'Free';
    }

    /**
     * Check if listing is available
     */
    public static function isAvailable(string $status): bool {
        return $status === 'available';
    }

    /**
     * Filter marketplace items by search term
     */
    public static function filterBySearch(array $items, string $searchTerm): array {
        if (empty($searchTerm)) {
            return $items;
        }
        
        $searchLower = strtolower($searchTerm);
        return array_filter($items, function($item) use ($searchLower) {
            return strpos(strtolower($item['title']), $searchLower) !== false ||
                   strpos(strtolower($item['description']), $searchLower) !== false;
        });
    }

    /**
     * Filter marketplace items by category
     */
    public static function filterByCategory(array $items, string $category): array {
        if (empty($category)) {
            return $items;
        }
        
        return array_filter($items, function($item) use ($category) {
            return $item['category'] === $category;
        });
    }

    /**
     * Sort marketplace items
     */
    public static function sortItems(array $items, string $sortBy): array {
        switch ($sortBy) {
            case 'price_low':
                usort($items, fn($a, $b) => $a['price'] <=> $b['price']);
                break;
            case 'price_high':
                usort($items, fn($a, $b) => $b['price'] <=> $a['price']);
                break;
            case 'newest':
            default:
                usort($items, fn($a, $b) => strtotime($b['created_at']) <=> strtotime($a['created_at']));
                break;
        }
        return $items;
    }
}

/**
 * Poll Helpers
 */
class PollHelper {
    /**
     * Check if poll is closed
     */
    public static function isClosed(array $poll): bool {
        if ($poll['status'] === 'closed') {
            return true;
        }
        
        if (!empty($poll['end_date']) && strtotime($poll['end_date']) < time()) {
            return true;
        }
        
        return false;
    }

    /**
     * Check if poll is active
     */
    public static function isActive(array $poll): bool {
        return !self::isClosed($poll);
    }

    /**
     * Calculate vote percentage
     */
    public static function calculatePercentage(int $optionVotes, int $totalVotes): int {
        if ($totalVotes <= 0) {
            return 0;
        }
        return (int) round(($optionVotes / $totalVotes) * 100);
    }

    /**
     * Validate poll creation data
     */
    public static function validatePoll(array $data): array {
        $errors = [];

        if (empty($data['question'])) {
            $errors[] = 'Question is required';
        }

        if (empty($data['options']) || !is_array($data['options'])) {
            $errors[] = 'Poll options are required';
        } else {
            $validOptions = array_filter($data['options'], fn($opt) => !empty(trim($opt)));
            if (count($validOptions) < 2) {
                $errors[] = 'At least 2 poll options are required';
            }
        }

        if (!empty($data['end_date'])) {
            $endDate = strtotime($data['end_date']);
            if ($endDate === false || $endDate < time()) {
                $errors[] = 'End date must be a valid future date';
            }
        }

        return $errors;
    }

    /**
     * Get total votes for a poll
     */
    public static function getTotalVotes(array $options): int {
        return array_sum(array_column($options, 'vote_count'));
    }

    /**
     * Check if user has already voted
     */
    public static function hasUserVoted(array $votes, int $userId, int $pollId): bool {
        foreach ($votes as $vote) {
            if ($vote['user_id'] == $userId && $vote['poll_id'] == $pollId) {
                return true;
            }
        }
        return false;
    }
}

/**
 * Announcement Helpers
 */
class AnnouncementHelper {
    const CATEGORIES = [
        'General',
        'Events',
        'Maintenance',
        'Safety',
        'Community',
        'Other'
    ];

    const STATUSES = ['draft', 'published'];

    /**
     * Validate announcement data
     */
    public static function validateAnnouncement(array $data): array {
        $errors = [];

        if (empty($data['title'])) {
            $errors[] = 'Title is required';
        }

        if (empty($data['category']) || !in_array($data['category'], self::CATEGORIES)) {
            $errors[] = 'Valid category is required';
        }

        if (empty($data['content'])) {
            $errors[] = 'Content is required';
        }

        return $errors;
    }

    /**
     * Check if user can delete announcement
     */
    public static function canDelete(array $announcement, array $user): bool {
        // Admin can delete any announcement
        if (!empty($user['is_admin'])) {
            return true;
        }
        
        // Creator can delete their own announcement
        return $announcement['created_by'] == $user['id'];
    }

    /**
     * Format announcement date
     */
    public static function formatDate(string $dateString): string {
        return date('M d, Y', strtotime($dateString));
    }

    /**
     * Increment view count
     */
    public static function incrementViews(int $currentViews): int {
        return $currentViews + 1;
    }
}

/**
 * Lost & Found Helpers
 */
class LostFoundHelper {
    const TYPES = ['lost', 'found'];
    
    const CATEGORIES = [
        'Electronics',
        'Jewelry',
        'Keys',
        'Wallet',
        'Documents',
        'Clothing',
        'Pets',
        'Other'
    ];

    const STATUSES = ['open', 'resolved'];

    /**
     * Validate lost/found item data
     */
    public static function validateItem(array $data): array {
        $errors = [];

        if (empty($data['type']) || !in_array($data['type'], self::TYPES)) {
            $errors[] = 'Type must be either "lost" or "found"';
        }

        if (empty($data['title'])) {
            $errors[] = 'Title is required';
        }

        if (empty($data['category']) || !in_array($data['category'], self::CATEGORIES)) {
            $errors[] = 'Valid category is required';
        }

        if (empty($data['description'])) {
            $errors[] = 'Description is required';
        }

        if (empty($data['location'])) {
            $errors[] = 'Location is required';
        }

        if (empty($data['date_occurred'])) {
            $errors[] = 'Date is required';
        }

        return $errors;
    }

    /**
     * Check if item is open (not resolved)
     */
    public static function isOpen(string $status): bool {
        return $status === 'open';
    }

    /**
     * Filter items by type
     */
    public static function filterByType(array $items, string $type): array {
        if (empty($type)) {
            return $items;
        }
        
        return array_filter($items, fn($item) => $item['type'] === $type);
    }
}

/**
 * Document Helpers
 */
class DocumentHelper {
    const ALLOWED_EXTENSIONS = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'];
    const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

    const CATEGORIES = [
        'Rules & Regulations',
        'Forms',
        'Meeting Minutes',
        'Financial Reports',
        'Notices',
        'Other'
    ];

    /**
     * Validate file upload
     */
    public static function validateFile(array $file): array {
        $errors = [];

        if (empty($file['name'])) {
            $errors[] = 'File is required';
            return $errors;
        }

        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, self::ALLOWED_EXTENSIONS)) {
            $errors[] = 'Invalid file type. Allowed: ' . implode(', ', self::ALLOWED_EXTENSIONS);
        }

        if ($file['size'] > self::MAX_FILE_SIZE) {
            $errors[] = 'File size exceeds maximum limit of 10MB';
        }

        return $errors;
    }

    /**
     * Format file size for display
     */
    public static function formatFileSize(int $bytes): string {
        if ($bytes >= 1048576) {
            return round($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return round($bytes / 1024, 2) . ' KB';
        } else {
            return $bytes . ' bytes';
        }
    }

    /**
     * Generate safe filename
     */
    public static function generateSafeFilename(string $originalName): string {
        $extension = pathinfo($originalName, PATHINFO_EXTENSION);
        $baseName = pathinfo($originalName, PATHINFO_FILENAME);
        $safeName = preg_replace('/[^a-zA-Z0-9_-]/', '_', $baseName);
        $timestamp = time();
        return "{$safeName}_{$timestamp}.{$extension}";
    }
}

/**
 * Community Directory Helpers
 */
class DirectoryHelper {
    /**
     * Validate profile data
     */
    public static function validateProfile(array $data): array {
        $errors = [];

        if (empty($data['name'])) {
            $errors[] = 'Name is required';
        }

        if (!empty($data['phone']) && !preg_match('/^[0-9\-\+\s\(\)]+$/', $data['phone'])) {
            $errors[] = 'Invalid phone number format';
        }

        return $errors;
    }

    /**
     * Filter directory by search term
     */
    public static function filterBySearch(array $profiles, string $searchTerm): array {
        if (empty($searchTerm)) {
            return $profiles;
        }
        
        $searchLower = strtolower($searchTerm);
        return array_filter($profiles, function($profile) use ($searchLower) {
            return strpos(strtolower($profile['name']), $searchLower) !== false ||
                   strpos(strtolower($profile['profession'] ?? ''), $searchLower) !== false ||
                   strpos(strtolower($profile['skills'] ?? ''), $searchLower) !== false;
        });
    }

    /**
     * Filter only visible profiles
     */
    public static function filterVisible(array $profiles): array {
        return array_filter($profiles, fn($p) => !empty($p['is_visible']));
    }
}

/**
 * Complaint Helpers
 */
class ComplaintHelper {
    const CATEGORIES = [
        'Maintenance',
        'Noise',
        'Parking',
        'Security',
        'Cleanliness',
        'Facilities',
        'Other'
    ];

    const STATUSES = ['Pending', 'Resolved', 'Rejected'];

    /**
     * Validate complaint data
     */
    public static function validateComplaint(array $data): array {
        $errors = [];

        if (empty($data['title'])) {
            $errors[] = 'Title is required';
        }

        if (empty($data['category']) || !in_array($data['category'], self::CATEGORIES)) {
            $errors[] = 'Valid category is required';
        }

        if (empty($data['description'])) {
            $errors[] = 'Description is required';
        }

        return $errors;
    }

    /**
     * Check if complaint is pending
     */
    public static function isPending(string $status): bool {
        return $status === 'Pending';
    }

    /**
     * Check if complaint is resolved
     */
    public static function isResolved(string $status): bool {
        return $status === 'Resolved';
    }
}

/**
 * FAQ Helpers  
 */
class FAQHelper {
    const CATEGORIES = [
        'General',
        'Events',
        'Payments',
        'Facilities',
        'Rules',
        'Maintenance',
        'Security',
        'Other'
    ];

    /**
     * Validate FAQ data
     */
    public static function validateFAQ(array $data): array {
        $errors = [];

        if (empty($data['question'])) {
            $errors[] = 'Question is required';
        }

        if (empty($data['answer'])) {
            $errors[] = 'Answer is required';
        }

        if (empty($data['category']) || !in_array($data['category'], self::CATEGORIES)) {
            $errors[] = 'Valid category is required';
        }

        return $errors;
    }

    /**
     * Group FAQs by category
     */
    public static function groupByCategory(array $faqs): array {
        $grouped = [];
        foreach ($faqs as $faq) {
            $category = $faq['category'] ?? 'Other';
            if (!isset($grouped[$category])) {
                $grouped[$category] = [];
            }
            $grouped[$category][] = $faq;
        }
        return $grouped;
    }

    /**
     * Filter FAQs by search term
     */
    public static function filterBySearch(array $faqs, string $searchTerm): array {
        if (empty($searchTerm)) {
            return $faqs;
        }
        
        $searchLower = strtolower($searchTerm);
        return array_filter($faqs, function($faq) use ($searchLower) {
            return strpos(strtolower($faq['question']), $searchLower) !== false ||
                   strpos(strtolower($faq['answer']), $searchLower) !== false;
        });
    }

    /**
     * Sort FAQs (pinned first, then by sort_order)
     */
    public static function sortFAQs(array $faqs): array {
        usort($faqs, function($a, $b) {
            // Pinned items first
            if (($a['is_pinned'] ?? 0) !== ($b['is_pinned'] ?? 0)) {
                return ($b['is_pinned'] ?? 0) - ($a['is_pinned'] ?? 0);
            }
            // Then by sort_order
            return ($a['sort_order'] ?? 999) - ($b['sort_order'] ?? 999);
        });
        return $faqs;
    }
}

/**
 * Event Helpers
 */
class EventHelper {
    const CATEGORIES = [
        'Sports',
        'Social',
        'Cultural',
        'Educational',
        'Meeting',
        'Other'
    ];

    /**
     * Validate event data
     */
    public static function validateEvent(array $data): array {
        $errors = [];

        if (empty($data['title'])) {
            $errors[] = 'Title is required';
        }

        if (empty($data['category']) || !in_array($data['category'], self::CATEGORIES)) {
            $errors[] = 'Valid category is required';
        }

        if (empty($data['date'])) {
            $errors[] = 'Date is required';
        }

        if (empty($data['time'])) {
            $errors[] = 'Time is required';
        }

        if (empty($data['location'])) {
            $errors[] = 'Location is required';
        }

        if (!isset($data['capacity']) || !is_numeric($data['capacity']) || $data['capacity'] < 1) {
            $errors[] = 'Valid capacity is required';
        }

        return $errors;
    }

    /**
     * Check if event is full
     */
    public static function isFull(int $capacity, int $registered): bool {
        return $registered >= $capacity;
    }

    /**
     * Get available spots
     */
    public static function getAvailableSpots(int $capacity, int $registered): int {
        return max(0, $capacity - $registered);
    }

    /**
     * Check if event is upcoming
     */
    public static function isUpcoming(string $date): bool {
        return strtotime($date) >= strtotime('today');
    }

    /**
     * Check if event is past
     */
    public static function isPast(string $date): bool {
        return strtotime($date) < strtotime('today');
    }
}