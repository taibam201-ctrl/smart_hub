#!/usr/bin/env php
<?php
/**
 * Smart Community Hub - Test Runner
 * 
 * Runs all unit tests for the application.
 * 
 * Usage: php tests/run_tests.php
 */

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Change to project directory
chdir(dirname(__DIR__));

echo "\n";
echo "╔══════════════════════════════════════════════════════════════════════╗\n";
echo "║          SMART COMMUNITY HUB - UNIT TEST SUITE                       ║\n";
echo "║          Running all tests...                                         ║\n";
echo "╚══════════════════════════════════════════════════════════════════════╝\n";

// Load test framework
require_once __DIR__ . '/TestFramework.php';
require_once __DIR__ . '/TestHelpers.php';

// Track time
$startTime = microtime(true);

// Load and run all test files
$testFiles = [
    'UserAuthenticationTest.php',
    'MarketplaceTest.php',
    'PollsTest.php',
    'AnnouncementsTest.php',
    'LostFoundTest.php',
    'DocumentsTest.php',
    'CommunityDirectoryTest.php',
    'ComplaintsTest.php',
    'FAQsTest.php',
    'EventsTest.php',
    'MockDatabaseTest.php'
];

foreach ($testFiles as $file) {
    $filePath = __DIR__ . '/' . $file;
    if (file_exists($filePath)) {
        require_once $filePath;
    } else {
        echo "⚠️  Warning: Test file not found: {$file}\n";
    }
}

// Run all tests
TestFramework::run();

// Calculate execution time
$endTime = microtime(true);
$executionTime = round($endTime - $startTime, 3);

echo "\n⏱️  Total execution time: {$executionTime} seconds\n\n";