<?php
/**
 * Unit Tests for FAQs
 * Tests FAQ validation, grouping, search, and sorting
 */

require_once __DIR__ . '/TestFramework.php';
require_once __DIR__ . '/TestHelpers.php';

TestFramework::setTestClass('FAQsTest');

// ============================================
// FAQ Validation Tests
// ============================================

TestFramework::test('Valid FAQ data passes validation', function() {
    $validFAQ = [
        'question' => 'What are the community pool hours?',
        'answer' => 'The pool is open from 6 AM to 10 PM daily.',
        'category' => 'Facilities'
    ];
    
    $errors = FAQHelper::validateFAQ($validFAQ);
    Assert::assertEmpty($errors, 'Valid FAQ should have no errors');
});

TestFramework::test('Missing question fails validation', function() {
    $faq = [
        'question' => '',
        'answer' => 'Some answer',
        'category' => 'General'
    ];
    
    $errors = FAQHelper::validateFAQ($faq);
    Assert::assertContains('Question is required', $errors);
});

TestFramework::test('Missing answer fails validation', function() {
    $faq = [
        'question' => 'Some question?',
        'answer' => '',
        'category' => 'General'
    ];
    
    $errors = FAQHelper::validateFAQ($faq);
    Assert::assertContains('Answer is required', $errors);
});

TestFramework::test('Missing category fails validation', function() {
    $faq = [
        'question' => 'Some question?',
        'answer' => 'Some answer',
        'category' => ''
    ];
    
    $errors = FAQHelper::validateFAQ($faq);
    Assert::assertContains('Valid category is required', $errors);
});

TestFramework::test('Invalid category fails validation', function() {
    $faq = [
        'question' => 'Some question?',
        'answer' => 'Some answer',
        'category' => 'InvalidCategory'
    ];
    
    $errors = FAQHelper::validateFAQ($faq);
    Assert::assertContains('Valid category is required', $errors);
});

TestFramework::test('All valid categories are accepted', function() {
    $categories = ['General', 'Events', 'Payments', 'Facilities', 'Rules', 'Maintenance', 'Security', 'Other'];
    
    foreach ($categories as $category) {
        $faq = [
            'question' => 'Test question?',
            'answer' => 'Test answer',
            'category' => $category
        ];
        
        $errors = FAQHelper::validateFAQ($faq);
        Assert::assertEmpty($errors, "Category '$category' should be valid");
    }
});

// ============================================
// Group By Category Tests
// ============================================

TestFramework::test('Group by category works correctly', function() {
    $faqs = [
        ['id' => 1, 'question' => 'Q1', 'category' => 'General'],
        ['id' => 2, 'question' => 'Q2', 'category' => 'Events'],
        ['id' => 3, 'question' => 'Q3', 'category' => 'General'],
        ['id' => 4, 'question' => 'Q4', 'category' => 'Security']
    ];
    
    $grouped = FAQHelper::groupByCategory($faqs);
    
    Assert::assertCount(3, $grouped); // 3 categories
    Assert::assertArrayHasKey('General', $grouped);
    Assert::assertArrayHasKey('Events', $grouped);
    Assert::assertArrayHasKey('Security', $grouped);
    Assert::assertCount(2, $grouped['General']);
    Assert::assertCount(1, $grouped['Events']);
});

TestFramework::test('Group by category handles empty array', function() {
    $grouped = FAQHelper::groupByCategory([]);
    Assert::assertEmpty($grouped);
});

TestFramework::test('Group by category handles missing category', function() {
    $faqs = [
        ['id' => 1, 'question' => 'Q1'],
        ['id' => 2, 'question' => 'Q2', 'category' => 'Events']
    ];
    
    $grouped = FAQHelper::groupByCategory($faqs);
    Assert::assertArrayHasKey('Other', $grouped);
    Assert::assertArrayHasKey('Events', $grouped);
});

// ============================================
// Search Filtering Tests
// ============================================

TestFramework::test('Filter by search in question works', function() {
    $faqs = [
        ['question' => 'What are the pool hours?', 'answer' => 'From 6 AM to 10 PM'],
        ['question' => 'Where is the gym?', 'answer' => 'Near the pool area'],
        ['question' => 'How do I pay fees?', 'answer' => 'Online payment available']
    ];
    
    $filtered = FAQHelper::filterBySearch($faqs, 'pool');
    Assert::assertCount(2, $filtered); // Found in question and answer
});

TestFramework::test('Filter by search in answer works', function() {
    $faqs = [
        ['question' => 'Question 1', 'answer' => 'The parking lot is near entrance'],
        ['question' => 'Question 2', 'answer' => 'Use the main gate'],
        ['question' => 'Where to park?', 'answer' => 'Designated area only']
    ];
    
    $filtered = FAQHelper::filterBySearch($faqs, 'parking');
    Assert::assertCount(1, $filtered);
});

TestFramework::test('Search is case-insensitive', function() {
    $faqs = [
        ['question' => 'POOL HOURS?', 'answer' => 'answer'],
        ['question' => 'pool timings?', 'answer' => 'answer'],
        ['question' => 'Other', 'answer' => 'answer']
    ];
    
    $filtered = FAQHelper::filterBySearch($faqs, 'pool');
    Assert::assertCount(2, $filtered);
});

TestFramework::test('Empty search returns all FAQs', function() {
    $faqs = [
        ['question' => 'Q1', 'answer' => 'A1'],
        ['question' => 'Q2', 'answer' => 'A2']
    ];
    
    $filtered = FAQHelper::filterBySearch($faqs, '');
    Assert::assertCount(2, $filtered);
});

// ============================================
// Sorting Tests
// ============================================

TestFramework::test('Sort FAQs puts pinned items first', function() {
    $faqs = [
        ['id' => 1, 'question' => 'Normal Q1', 'is_pinned' => 0, 'sort_order' => 1],
        ['id' => 2, 'question' => 'Pinned Q', 'is_pinned' => 1, 'sort_order' => 5],
        ['id' => 3, 'question' => 'Normal Q2', 'is_pinned' => 0, 'sort_order' => 2]
    ];
    
    $sorted = FAQHelper::sortFAQs($faqs);
    Assert::assertEquals(2, $sorted[0]['id']); // Pinned should be first
});

TestFramework::test('Sort FAQs by sort_order when pinned status equal', function() {
    $faqs = [
        ['id' => 1, 'question' => 'Q1', 'is_pinned' => 0, 'sort_order' => 3],
        ['id' => 2, 'question' => 'Q2', 'is_pinned' => 0, 'sort_order' => 1],
        ['id' => 3, 'question' => 'Q3', 'is_pinned' => 0, 'sort_order' => 2]
    ];
    
    $sorted = FAQHelper::sortFAQs($faqs);
    Assert::assertEquals(2, $sorted[0]['id']); // sort_order 1
    Assert::assertEquals(3, $sorted[1]['id']); // sort_order 2
    Assert::assertEquals(1, $sorted[2]['id']); // sort_order 3
});

TestFramework::test('Sort FAQs handles missing sort_order', function() {
    $faqs = [
        ['id' => 1, 'question' => 'Q1', 'is_pinned' => 0],
        ['id' => 2, 'question' => 'Q2', 'is_pinned' => 1],
        ['id' => 3, 'question' => 'Q3', 'is_pinned' => 0, 'sort_order' => 1]
    ];
    
    $sorted = FAQHelper::sortFAQs($faqs);
    Assert::assertEquals(2, $sorted[0]['id']); // Pinned first
    Assert::assertEquals(3, $sorted[1]['id']); // Has sort_order 1
});

TestFramework::test('Multiple pinned items sorted by sort_order', function() {
    $faqs = [
        ['id' => 1, 'question' => 'Pinned 2', 'is_pinned' => 1, 'sort_order' => 2],
        ['id' => 2, 'question' => 'Pinned 1', 'is_pinned' => 1, 'sort_order' => 1],
        ['id' => 3, 'question' => 'Normal', 'is_pinned' => 0, 'sort_order' => 1]
    ];
    
    $sorted = FAQHelper::sortFAQs($faqs);
    Assert::assertEquals(2, $sorted[0]['id']); // Pinned, sort_order 1
    Assert::assertEquals(1, $sorted[1]['id']); // Pinned, sort_order 2
    Assert::assertEquals(3, $sorted[2]['id']); // Not pinned
});

// ============================================
// Constants Tests
// ============================================

TestFramework::test('All FAQ categories are defined', function() {
    $expectedCategories = ['General', 'Events', 'Payments', 'Facilities', 'Rules', 'Maintenance', 'Security', 'Other'];
    Assert::assertEquals($expectedCategories, FAQHelper::CATEGORIES);
});

// ============================================
// Multiple Validation Errors Test
// ============================================

TestFramework::test('Multiple validation errors are all returned', function() {
    $faq = [
        'question' => '',
        'answer' => '',
        'category' => 'Invalid'
    ];
    
    $errors = FAQHelper::validateFAQ($faq);
    Assert::assertCount(3, $errors);
});