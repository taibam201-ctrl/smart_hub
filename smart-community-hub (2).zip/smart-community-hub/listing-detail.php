<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$listingId = (int)($_GET['id'] ?? 0);

if (!$listingId) {
    header('Location: marketplace.php');
    exit();
}

$sql = "SELECT m.*, u.username, u.email FROM marketplace m JOIN users u ON m.user_id = u.id WHERE m.id = $listingId";
$result = $conn->query($sql);

if (!$result || $result->num_rows === 0) {
    header('Location: marketplace.php');
    exit();
}

$listing = $result->fetch_assoc();

// Handle mark as sold
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_sold']) && $listing['user_id'] == $user['id']) {
    $conn->query("UPDATE marketplace SET status = 'sold' WHERE id = $listingId");
    header("Location: listing-detail.php?id=$listingId&sold=1");
    exit();
}

// Handle delete
if (isset($_GET['delete']) && ($listing['user_id'] == $user['id'] || isAdmin())) {
    $conn->query("DELETE FROM marketplace WHERE id = $listingId");
    header('Location: marketplace.php?deleted=1');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($listing['title']); ?> - Marketplace</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <?php if (isset($_GET['sold'])): ?>
            <div class="message success">Item marked as sold!</div>
        <?php endif; ?>

        <div style="max-width: 900px; margin: 0 auto;">
            <div style="background: var(--glass); border: 1px solid rgba(124,58,237,0.3); border-radius: 20px; overflow: hidden;">
                
                <div style="height: 400px; overflow: hidden; position: relative;">
                    <img src="<?= htmlspecialchars($listing['image_url']); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                    <?php if ($listing['status'] === 'sold'): ?>
                        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(239, 68, 68, 0.9); padding: 1rem 3rem; border-radius: 10px; font-size: 2rem; font-weight: 800;">SOLD</div>
                    <?php endif; ?>
                    <span style="position: absolute; top: 1rem; right: 1rem; background: linear-gradient(135deg, var(--primary), var(--secondary)); padding: 0.5rem 1rem; border-radius: 20px; font-weight: 700;">
                        <?= htmlspecialchars($listing['category']); ?>
                    </span>
                </div>

                <div style="padding: 2rem;">
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
                        <div>
                            <h1 style="font-size: 2rem; margin-bottom: 0.5rem;"><?= htmlspecialchars($listing['title']); ?></h1>
                            <p style="font-size: 2rem; font-weight: 800; color: var(--secondary);">
                                <?= $listing['price'] > 0 ? 'Rs. ' . number_format($listing['price']) : 'FREE'; ?>
                            </p>
                        </div>
                        
                        <?php if ($listing['user_id'] == $user['id']): ?>
                            <div style="display: flex; gap: 0.5rem;">
                                <?php if ($listing['status'] !== 'sold'): ?>
                                    <form method="POST" style="display: inline;">
                                        <button type="submit" name="mark_sold" class="btn btn-small" onclick="return confirm('Mark this item as sold?');">Mark as Sold</button>
                                    </form>
                                <?php endif; ?>
                                <a href="listing-detail.php?id=<?= $listingId; ?>&delete=1" class="btn btn-small btn-danger" onclick="return confirm('Delete this listing?');">Delete</a>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 2rem; padding: 1.5rem; background: rgba(124,58,237,0.1); border-radius: 12px;">
                        <div>
                            <small style="opacity: 0.7;">Condition</small>
                            <p style="font-weight: 700; margin: 0;"><?= ucfirst(str_replace('_', ' ', $listing['condition'])); ?></p>
                        </div>
                        <div>
                            <small style="opacity: 0.7;">Posted By</small>
                            <p style="font-weight: 700; margin: 0; color: var(--secondary);"><?= htmlspecialchars($listing['username']); ?></p>
                        </div>
                        <div>
                            <small style="opacity: 0.7;">Posted On</small>
                            <p style="font-weight: 700; margin: 0;"><?= date('M d, Y', strtotime($listing['created_at'])); ?></p>
                        </div>
                        <div>
                            <small style="opacity: 0.7;">Status</small>
                            <p style="font-weight: 700; margin: 0; color: <?= $listing['status'] === 'sold' ? 'var(--error)' : 'var(--success)'; ?>;">
                                <?= ucfirst($listing['status']); ?>
                            </p>
                        </div>
                    </div>

                    <div style="margin-bottom: 2rem;">
                        <h3 style="margin-bottom: 1rem;">Description</h3>
                        <p style="line-height: 1.8; opacity: 0.9;"><?= nl2br(htmlspecialchars($listing['description'])); ?></p>
                    </div>

                    <?php if ($listing['status'] !== 'sold' && $listing['user_id'] != $user['id']): ?>
                        <div style="background: rgba(6, 182, 212, 0.1); border: 1px solid var(--secondary); border-radius: 12px; padding: 1.5rem;">
                            <h3 style="margin-bottom: 1rem;">📞 Contact Seller</h3>
                            <p style="margin-bottom: 0.5rem;"><strong>Phone:</strong> <?= htmlspecialchars($listing['contact_phone']); ?></p>
                            <p style="margin-bottom: 0;"><strong>Email:</strong> <?= htmlspecialchars($listing['email']); ?></p>
                        </div>
                    <?php endif; ?>

                    <a href="marketplace.php" class="btn" style="margin-top: 2rem;">← Back to Marketplace</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
