<?php
require __DIR__ . '/config.php';
requireLogin();

$user = getCurrentUser();
$announcementId = (int)($_GET['id'] ?? 0);

if (!$announcementId) {
    header('Location: announcements.php');
    exit();
}

$sql = "
    SELECT a.*, u.username
    FROM announcements a
    JOIN users u ON a.created_by = u.id
    WHERE a.id = $announcementId AND a.status = 'published'
";

$result = $conn->query($sql);

if (!$result || $result->num_rows === 0) {
    header('Location: announcements.php');
    exit();
}

$announcement = $result->fetch_assoc();
$createdDate = new DateTime($announcement['created_at']);

$conn->query("UPDATE announcements SET views = views + 1 WHERE id = $announcementId");
$announcement['views']++;

$commentMessage = '';
$commentType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_comment'])) {
    $comment = trim($conn->real_escape_string($_POST['comment'] ?? ''));

    if ($comment !== '') {
        $userId = $user['id'];

        $insertSql = "
            INSERT INTO announcement_comments (announcement_id, user_id, comment)
            VALUES ($announcementId, $userId, '$comment')
        ";

        if ($conn->query($insertSql)) {
            $commentMessage = 'Comment posted successfully!';
            $commentType = 'success';
        } else {
            $commentMessage = 'Error posting comment.';
            $commentType = 'error';
        }
    } else {
        $commentMessage = 'Comment cannot be empty!';
        $commentType = 'error';
    }
}

$commentsResult = $conn->query("
    SELECT c.*, u.username
    FROM announcement_comments c
    JOIN users u ON c.user_id = u.id
    WHERE c.announcement_id = $announcementId
    ORDER BY c.created_at DESC
");

$comments = $commentsResult ? $commentsResult->fetch_all(MYSQLI_ASSOC) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($announcement['title']); ?> - Smart Community Hub</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<!-- ✅ ONE CONSISTENT NAVBAR -->
<?php include __DIR__ . '/partials/navbar.php'; ?>

<div class="container">

    <div class="hero" style="margin-bottom:2rem; max-width:900px;">
        <h1><?= htmlspecialchars($announcement['title']); ?></h1>
        <p>Share important updates and news with your community</p>
    </div>

    <div style="
        max-width:900px;
        margin:0 auto;
        background:var(--glass);
        border:1px solid rgba(124,58,237,0.3);
        border-radius:20px;
        overflow:hidden;
        box-shadow:0 15px 40px rgba(0,0,0,0.35);
    ">

        <div style="height:400px; overflow:hidden;">
            <img src="<?= htmlspecialchars($announcement['image_url']); ?>"
                 style="width:100%; height:100%; object-fit:cover;">
        </div>

        <div style="padding:3rem;">

            <div style="display:flex; justify-content:space-between; margin-bottom:2rem;">
                <div>
                    <span style="
                        background:linear-gradient(135deg,var(--primary),var(--secondary));
                        padding:0.5rem 1rem;
                        border-radius:20px;
                        color:white;
                        font-size:0.85rem;
                        font-weight:700;
                    ">
                        <?= htmlspecialchars($announcement['category']); ?>
                    </span>

                    <h1 style="font-size:2.3rem; margin-top:1rem;">
                        <?= htmlspecialchars($announcement['title']); ?>
                    </h1>
                </div>

                <?php if (isAdmin()): ?>
                    <a href="delete-announcement.php?id=<?= $announcementId; ?>"
                       onclick="return confirm('Delete this announcement?')"
                       class="btn btn-small">
                        Delete
                    </a>
                <?php endif; ?>
            </div>

            <div style="
                display:flex;
                gap:2rem;
                flex-wrap:wrap;
                margin-bottom:2rem;
                padding-bottom:2rem;
                border-bottom:1px solid rgba(124,58,237,0.3);
            ">
                <div>
                    <small>By</small>
                    <p style="margin:0; font-weight:700; color:var(--secondary);">
                        <?= htmlspecialchars($announcement['username']); ?>
                    </p>
                </div>

                <div>
                    <small>Published</small>
                    <p style="margin:0; font-weight:700;">
                        <?= $createdDate->format('M d, Y h:i A'); ?>
                    </p>
                </div>

                <div>
                    <small>Views</small>
                    <p style="margin:0; font-weight:700;">
                        👁 <?= $announcement['views']; ?>
                    </p>
                </div>
            </div>

            <div style="font-size:1.1rem; line-height:1.8; margin-bottom:2rem;">
                <?= nl2br(htmlspecialchars($announcement['content'])); ?>
            </div>

            <h2 style="font-size:1.8rem; margin-bottom:1rem;">
                Comments (<?= count($comments); ?>)
            </h2>

            <?php if ($commentMessage): ?>
                <div class="message <?= htmlspecialchars($commentType); ?>" style="margin-bottom:1.5rem;">
                    <?= htmlspecialchars($commentMessage); ?>
                </div>
            <?php endif; ?>

            <form method="POST" style="margin-bottom:2rem;">
                <label style="font-weight:700;">Add a Comment</label>
                <textarea name="comment" required
                    style="width:100%; min-height:120px; background:rgba(0,0,0,0.3);
                           border:1px solid rgba(124,58,237,0.5);
                           border-radius:12px; padding:1rem; color:white;">
                </textarea>
                <button class="btn" name="add_comment" style="margin-top:1rem;">
                    Post Comment
                </button>
            </form>

            <?php foreach ($comments as $c):
                $cDate = new DateTime($c['created_at']); ?>
                <div style="background:rgba(124,58,237,0.15); padding:1rem 1.5rem; margin-bottom:1rem; border-radius:10px;">
                    <strong style="color:var(--secondary);">
                        <?= htmlspecialchars($c['username']); ?>
                    </strong>
                    <small style="opacity:0.6;">
                        • <?= $cDate->format('M d, Y h:i A'); ?>
                    </small>
                    <p style="margin-top:0.5rem;">
                        <?= nl2br(htmlspecialchars($c['comment'])); ?>
                    </p>
                </div>
            <?php endforeach; ?>

            <a href="announcements.php" class="btn" style="margin-top:2rem;">
                Back to Announcements
            </a>

        </div>
    </div>
</div>

</body>
</html>
