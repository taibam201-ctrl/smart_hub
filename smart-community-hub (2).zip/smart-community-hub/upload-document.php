<?php
include 'config.php';
requireLogin();

if (!isAdmin()) {
    header('Location: documents.php');
    exit();
}

$user = getCurrentUser();
$message = '';
$messageType = '';

$categories = [
    'Rules & Regulations',
    'Forms',
    'Meeting Minutes',
    'Financial Reports',
    'Notices',
    'Guidelines',
    'Other'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $conn->real_escape_string($_POST['title'] ?? '');
    $category = $conn->real_escape_string($_POST['category'] ?? '');
    $description = $conn->real_escape_string($_POST['description'] ?? '');
    $userId = $user['id'];

    if ($title && $category) {
        $fileName = '';
        $fileSize = 0;
        $filePath = '';

        // Handle file upload
        if (isset($_FILES['document']) && $_FILES['document']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/documents/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $originalName = $_FILES['document']['name'];
            $fileSize = $_FILES['document']['size'];
            $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
            
            // Allowed file types
            $allowed = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'jpg', 'jpeg', 'png'];
            
            if (in_array($extension, $allowed)) {
                $fileName = time() . '_' . preg_replace('/[^a-zA-Z0-9.]/', '_', $originalName);
                $filePath = $uploadDir . $fileName;
                
                if (move_uploaded_file($_FILES['document']['tmp_name'], $filePath)) {
                    // File uploaded successfully
                } else {
                    $message = "Error uploading file!";
                    $messageType = "error";
                }
            } else {
                $message = "Invalid file type! Allowed: " . implode(', ', $allowed);
                $messageType = "error";
            }
        }

        if ($messageType !== 'error') {
            $sql = "INSERT INTO documents (title, category, description, file_name, file_path, file_size, uploaded_by)
                    VALUES ('$title', '$category', '$description', '$fileName', '$filePath', $fileSize, $userId)";
            
            if ($conn->query($sql)) {
                $message = "Document uploaded successfully!";
                $messageType = "success";
            } else {
                $message = "Error: " . $conn->error;
                $messageType = "error";
            }
        }
    } else {
        $message = "Please fill all required fields!";
        $messageType = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Document - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>📤 Upload Document</h1>
            <p>Share important documents with the community</p>
        </div>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>">
                <?= $message ?>
                <?php if ($messageType === 'success'): ?>
                    <br><a href="documents.php" style="color: inherit; text-decoration: underline;">View All Documents</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Document Title *</label>
                    <input type="text" name="title" placeholder="e.g., Community Rules 2025" required>
                </div>

                <div class="form-group">
                    <label>Category *</label>
                    <select name="category" required>
                        <option value="">Select Category</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat; ?>"><?= $cat; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" placeholder="Brief description of the document..." style="min-height: 100px;"></textarea>
                </div>

                <div class="form-group">
                    <label>Upload File *</label>
                    <input type="file" name="document" required style="padding: 1rem; background: rgba(255,255,255,0.08); border-radius: 12px; width: 100%;">
                    <small style="color: rgba(226, 232, 240, 0.6); display: block; margin-top: 0.5rem;">
                        Allowed: PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX, TXT, JPG, PNG (Max 10MB)
                    </small>
                </div>

                <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                    <button type="submit" class="btn">Upload Document</button>
                    <a href="documents.php" class="btn" style="background: rgba(255,255,255,0.1);">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
