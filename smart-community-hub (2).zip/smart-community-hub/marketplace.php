<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();
$searchTerm = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$categoryFilter = isset($_GET['category']) ? $conn->real_escape_string($_GET['category']) : '';
$sortBy = isset($_GET['sort']) ? $conn->real_escape_string($_GET['sort']) : 'newest';

$sql = "SELECT m.*, u.username FROM marketplace m JOIN users u ON m.user_id = u.id WHERE m.status = 'available'";

if ($searchTerm) {
    $sql .= " AND (m.title LIKE '%$searchTerm%' OR m.description LIKE '%$searchTerm%')";
}

if ($categoryFilter) {
    $sql .= " AND m.category = '$categoryFilter'";
}

if ($sortBy === 'price_low') {
    $sql .= " ORDER BY m.price ASC";
} elseif ($sortBy === 'price_high') {
    $sql .= " ORDER BY m.price DESC";
} else {
    $sql .= " ORDER BY m.created_at DESC";
}

$result = $conn->query($sql);
$items = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>🛒 Community Marketplace</h1>
            <p>Buy, sell, and trade items within your community</p>
        </div>

        <div style="text-align: right; margin-bottom: 1.5rem;">
            <a href="add-listing.php" class="btn">+ Add New Listing</a>
        </div>

        <div class="search-filter">
            <form method="GET" style="display: contents;">
                <input type="text" name="search" placeholder="Search items..." value="<?= htmlspecialchars($searchTerm); ?>">
                
                <select name="category">
                    <option value="">All Categories</option>
                    <option value="Electronics" <?= $categoryFilter === 'Electronics' ? 'selected' : ''; ?>>Electronics</option>
                    <option value="Furniture" <?= $categoryFilter === 'Furniture' ? 'selected' : ''; ?>>Furniture</option>
                    <option value="Clothing" <?= $categoryFilter === 'Clothing' ? 'selected' : ''; ?>>Clothing</option>
                    <option value="Books" <?= $categoryFilter === 'Books' ? 'selected' : ''; ?>>Books</option>
                    <option value="Sports" <?= $categoryFilter === 'Sports' ? 'selected' : ''; ?>>Sports & Fitness</option>
                    <option value="Home" <?= $categoryFilter === 'Home' ? 'selected' : ''; ?>>Home & Garden</option>
                    <option value="Services" <?= $categoryFilter === 'Services' ? 'selected' : ''; ?>>Services</option>
                    <option value="Other" <?= $categoryFilter === 'Other' ? 'selected' : ''; ?>>Other</option>
                </select>

                <select name="sort">
                    <option value="newest" <?= $sortBy === 'newest' ? 'selected' : ''; ?>>Newest First</option>
                    <option value="price_low" <?= $sortBy === 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                    <option value="price_high" <?= $sortBy === 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
                </select>

                <button type="submit" class="btn btn-small">Search</button>
            </form>
        </div>

        <?php if (count($items) > 0): ?>
            <div class="grid">
                <?php foreach ($items as $item): ?>
                    <div class="event-card">
                        <div class="event-image">
                            <img src="<?= htmlspecialchars($item['image_url'] ?: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&h=300&fit=crop'); ?>" alt="<?= htmlspecialchars($item['title']); ?>">
                            <div class="event-badge"><?= htmlspecialchars($item['category']); ?></div>
                        </div>
                        <div class="event-info">
                            <h3 class="event-title"><?= htmlspecialchars($item['title']); ?></h3>
                            <div class="event-details">
                                <div class="event-detail-row">
                                    <span class="event-detail-icon">💰</span>
                                    <span style="font-size: 1.3rem; font-weight: 700; color: var(--secondary);">
                                        <?= $item['price'] > 0 ? 'Rs. ' . number_format($item['price']) : 'Free'; ?>
                                    </span>
                                </div>
                                <div class="event-detail-row">
                                    <span class="event-detail-icon">👤</span>
                                    <span><?= htmlspecialchars($item['username']); ?></span>
                                </div>
                                <div class="event-detail-row">
                                    <span class="event-detail-icon">📅</span>
                                    <span><?= date('M d, Y', strtotime($item['created_at'])); ?></span>
                                </div>
                            </div>
                            <p class="event-description"><?= substr(htmlspecialchars($item['description']), 0, 100); ?>...</p>
                            <div class="event-footer">
                                <span style="color: rgba(226, 232, 240, 0.6); font-size: 0.85rem;">
                                    <?= ucfirst($item['condition']); ?> condition
                                </span>
                                <a href="listing-detail.php?id=<?= $item['id']; ?>" class="btn btn-small">View Details</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h3>No Items Found</h3>
                <p>Be the first to list an item in the marketplace!</p>
                <a href="add-listing.php" class="btn">Add Listing</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
