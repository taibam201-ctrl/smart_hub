<?php
include 'config.php';
requireLogin();

if (!isAdmin()) {
    header('Location: polls.php');
    exit();
}

$pollId = (int)($_GET['id'] ?? 0);

if ($pollId) {
    $conn->query("UPDATE polls SET status = 'closed' WHERE id = $pollId");
}

header('Location: polls.php');
exit();
?>
