<?php
include 'config.php';
requireLogin();

$user = getCurrentUser();

// Get existing profile
$result = $conn->query("SELECT * FROM community_directory WHERE user_id = {$user['id']}");
if (!$result || $result->num_rows === 0) {
    header('Location: add-profile.php');
    exit();
}

$profile = $result->fetch_assoc();
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name'] ?? '');
    $phone = $conn->real_escape_string($_POST['phone'] ?? '');
    $block = $conn->real_escape_string($_POST['block'] ?? '');
    $unit = $conn->real_escape_string($_POST['unit'] ?? '');
    $profession = $conn->real_escape_string($_POST['profession'] ?? '');
    $skills = $conn->real_escape_string($_POST['skills'] ?? '');
    $bio = $conn->real_escape_string($_POST['bio'] ?? '');
    $show_phone = isset($_POST['show_phone']) ? 1 : 0;
    $show_email = isset($_POST['show_email']) ? 1 : 0;
    $is_visible = isset($_POST['is_visible']) ? 1 : 0;

    if ($name) {
        $sql = "UPDATE community_directory SET 
                name = '$name', phone = '$phone', block = '$block', unit = '$unit',
                profession = '$profession', skills = '$skills', bio = '$bio',
                show_phone = $show_phone, show_email = $show_email, is_visible = $is_visible
                WHERE user_id = {$user['id']}";
        
        if ($conn->query($sql)) {
            $message = "Profile updated successfully!";
            $messageType = "success";
            // Refresh profile data
            $result = $conn->query("SELECT * FROM community_directory WHERE user_id = {$user['id']}");
            $profile = $result->fetch_assoc();
        } else {
            $message = "Error: " . $conn->error;
            $messageType = "error";
        }
    } else {
        $message = "Please enter your name!";
        $messageType = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit My Profile - Smart Community Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="background">
        <div class="float-shape shape-1"></div>
        <div class="float-shape shape-2"></div>
        <div class="float-shape shape-3"></div>
    </div>

    <?php include 'partials/navbar.php'; ?>

    <div class="container">
        <div class="hero">
            <h1>✏️ Edit My Profile</h1>
            <p>Update your community directory profile</p>
        </div>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>"><?= $message ?></div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST">
                <div class="form-group">
                    <label>Full Name *</label>
                    <input type="text" name="name" value="<?= htmlspecialchars($profile['name']); ?>" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div class="form-group">
                        <label>Block/Building</label>
                        <select name="block">
                            <option value="">Select Block</option>
                            <option value="A" <?= $profile['block'] === 'A' ? 'selected' : ''; ?>>Block A</option>
                            <option value="B" <?= $profile['block'] === 'B' ? 'selected' : ''; ?>>Block B</option>
                            <option value="C" <?= $profile['block'] === 'C' ? 'selected' : ''; ?>>Block C</option>
                            <option value="D" <?= $profile['block'] === 'D' ? 'selected' : ''; ?>>Block D</option>
                            <option value="E" <?= $profile['block'] === 'E' ? 'selected' : ''; ?>>Block E</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Unit/Apartment Number</label>
                        <input type="text" name="unit" value="<?= htmlspecialchars($profile['unit']); ?>">
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" name="phone" value="<?= htmlspecialchars($profile['phone']); ?>">
                    </div>

                    <div class="form-group">
                        <label>Profession</label>
                        <input type="text" name="profession" value="<?= htmlspecialchars($profile['profession']); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label>Skills/Expertise</label>
                    <input type="text" name="skills" value="<?= htmlspecialchars($profile['skills']); ?>">
                </div>

                <div class="form-group">
                    <label>Bio</label>
                    <textarea name="bio" style="min-height: 100px;"><?= htmlspecialchars($profile['bio']); ?></textarea>
                </div>

                <div style="background: rgba(124,58,237,0.1); padding: 1.5rem; border-radius: 12px; margin-bottom: 1.5rem;">
                    <h4 style="margin-bottom: 1rem;">Privacy Settings</h4>
                    <div style="display: flex; flex-direction: column; gap: 0.8rem;">
                        <label style="display: flex; align-items: center; gap: 0.8rem; cursor: pointer;">
                            <input type="checkbox" name="show_phone" <?= $profile['show_phone'] ? 'checked' : ''; ?>>
                            <span>Show my phone number</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 0.8rem; cursor: pointer;">
                            <input type="checkbox" name="show_email" <?= $profile['show_email'] ? 'checked' : ''; ?>>
                            <span>Show my email</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 0.8rem; cursor: pointer;">
                            <input type="checkbox" name="is_visible" <?= $profile['is_visible'] ? 'checked' : ''; ?>>
                            <span>Make profile visible</span>
                        </label>
                    </div>
                </div>

                <div style="display: flex; gap: 1rem;">
                    <button type="submit" class="btn">Update Profile</button>
                    <a href="directory.php" class="btn" style="background: rgba(255,255,255,0.1);">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
